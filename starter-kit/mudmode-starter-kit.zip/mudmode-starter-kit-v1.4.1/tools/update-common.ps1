# Windows update helpers. Target runtimes: Windows PowerShell 5.1 / PowerShell 7; not a runtime test certification.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
function Get-MudHash([byte[]]$Bytes) { $s=[Security.Cryptography.SHA256]::Create(); try { ([BitConverter]::ToString($s.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() } finally { $s.Dispose() } }
function Write-MudText($Path,$Text) { [IO.File]::WriteAllText($Path,$Text,(New-Object Text.UTF8Encoding $false)) }
function Test-MudProtected($Path) {
 $v=$Path.ToLowerInvariant(); return ($v -match '^(core-local\.md|handoff(?:\.md|/|$)|lessons\.md|jobs(?:\.md|/|$)|ok-ledger\.md)$' -or $v -match '^(jobs|handoff)/' -or $v -match '\.bak-' -or $v -match '(^|/)[^/]*(password|passwd|credential|secret|token)[^/]*$' -or $v -match '(^|/)(deny-list[^/]*|[^/]*\.private(?:\.[^/]*)?|\.env[^/]*|[^/]*\.(?:pem|key|pfx|p12)|id_rsa|credentials[^/]*|secrets?[^/]*)$')
}
function Assert-MudPath($Path) {
 if (-not ($Path -is [string]) -or $Path.Length -gt 220 -or $Path -notmatch '^[A-Za-z0-9_(). -]+(/[A-Za-z0-9_(). -]+)*$') { throw 'Unsafe pack path' }
 foreach($c in $Path.Split('/')) { if ($c -eq '.' -or $c -eq '..' -or $c.EndsWith('.') -or $c.EndsWith(' ') -or $c -match '^(?i:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)') { throw 'Unsafe path component' } }
 if (Test-MudProtected $Path) { throw 'Personal path in pack' }
}
function Assert-MudTree($Root) {
 $q=Get-Item -LiteralPath $Root -Force
 while($q) { if (($q.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked target or ancestor refused' }; $q=$q.Parent }
 $todo=New-Object 'Collections.Generic.Stack[string]'; $todo.Push($Root)
 while($todo.Count) { foreach($it in Get-ChildItem -LiteralPath $todo.Pop() -Force) { if (($it.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked file/folder refused' }; if($it.PSIsContainer) { $todo.Push($it.FullName) } } }
}
function Get-MudSnapshot($Root) {
 Assert-MudTree $Root; $out=@{}; $prefix=$Root.TrimEnd('/','\')+[IO.Path]::DirectorySeparatorChar
 foreach($it in Get-ChildItem -LiteralPath $Root -Force -Recurse -File) { $p=$it.FullName.Substring($prefix.Length).Replace('\','/'); $out[$p]=[IO.File]::ReadAllBytes($it.FullName) }; return ,$out
}
# Read one zip entry with a hard cap on the bytes really inflated. Zip headers are attacker text: never trust them alone
# (.NET Framework 4.8 / PS 5.1 inflates past the declared size; .NET 10 stops at it).
function Get-MudEntryBytes($Entry,[long]$Max=33554432) {
 $declared=[long]$Entry.Length
 if($declared -gt $Max) {throw "Zip entry larger than allowed: $($Entry.FullName)"}
 if($declared -gt 1048576 -and $Entry.CompressedLength -gt 0 -and ($declared / [double]$Entry.CompressedLength) -gt 250) {throw "Zip entry compression ratio too high: $($Entry.FullName)"}
 $s=$Entry.Open(); $m=New-Object IO.MemoryStream; $buf=New-Object byte[] 65536; [long]$got=0
 try {
  while(($n=$s.Read($buf,0,$buf.Length)) -gt 0) { $got+=$n; if($got -gt $declared) {throw "Zip entry is bigger than its header says; refused: $($Entry.FullName)"}; $m.Write($buf,0,$n) }
  if($got -ne $declared) {throw "Zip entry size does not match its header: $($Entry.FullName)"}
  return ,$m.ToArray()
 } finally {$s.Dispose();$m.Dispose()}
}
function Get-MudFileHash($Path) { $s=[Security.Cryptography.SHA256]::Create(); $f=[IO.File]::OpenRead($Path); try { ([BitConverter]::ToString($s.ComputeHash($f))).Replace('-','').ToLowerInvariant() } finally { $f.Dispose(); $s.Dispose() } }
function Write-MudTextAtomic($Path,$Text,$Root='') { Write-MudBytesAtomic $Path ([Text.Encoding]::UTF8.GetBytes($Text)) $Root }
function Write-MudBytesAtomic($Path,[byte[]]$Bytes,$Root='') {
 [IO.Directory]::CreateDirectory((Split-Path -Parent $Path))|Out-Null
 $id=[Guid]::NewGuid().ToString('N');$tmp=$Path+'.tmp-'+$id;$marker=$null
 if($Root) {
  $rel=$Path.Substring($Root.Length+1).Replace('\','/');$marker=Join-Path (Split-Path -Parent $Root) ('.'+(Split-Path -Leaf $Root)+'.mudmode-write-'+$id+'.json')
  $mb=[Text.Encoding]::UTF8.GetBytes((@{type='mudmode-atomic-temp-v1';id=$id;kit=$Root;target=$rel;pid=$PID}|ConvertTo-Json -Compress))
  $mf=[IO.File]::Open($marker,[IO.FileMode]::CreateNew);try {$mf.Write($mb,0,$mb.Length);$mf.Flush()} finally {$mf.Dispose()}
 }
 $f=[IO.File]::Open($tmp,[IO.FileMode]::CreateNew)
 try {$cut=[Math]::Min(1024,$Bytes.Length);$f.Write($Bytes,0,$cut);$f.Flush();if($marker) {Invoke-MudCrashHook 'atomic-temp-written'};$f.Write($Bytes,$cut,$Bytes.Length-$cut)} finally {$f.Dispose()}
 if(Test-Path -LiteralPath $Path) {[IO.File]::Replace($tmp,$Path,[NullString]::Value)} else {[IO.File]::Move($tmp,$Path)}
 if($marker) {[IO.File]::Delete($marker)}
}
function Test-MudPid($Value) { return (($Value -is [int] -or $Value -is [long]) -and $Value -gt 0 -and $Value -le 2147483647) }
function Read-MudJsonSmall($Path) { if((Get-Item -LiteralPath $Path -Force).Length -gt 16777216) {throw "Record file too large: $Path"}; return ([IO.File]::ReadAllText($Path) | ConvertFrom-Json) }
function ConvertTo-MudHashTable($Obj) { $h=@{}; if($Obj) { foreach($pr in $Obj.PSObject.Properties) { $h[$pr.Name]=[string]$pr.Value } }; return $h }
# The backup must be a mudmode backup next to the folder, match its recorded hash, and hold exactly the recorded files.
function Get-MudCheckedBackup($Root,$Path,$Sha,$Files) {
 if(-not $Path -or -not $Sha -or -not $Files) {throw 'Update record has no backup hashes; refused. Nothing changed.'}
 $parent=[IO.Path]::GetFullPath((Split-Path -Parent $Root)).TrimEnd('/','\'); $full=[IO.Path]::GetFullPath([string]$Path)
 if(([IO.Path]::GetDirectoryName($full)).TrimEnd('/','\') -ne $parent -or (Split-Path -Leaf $full) -notmatch '^mudmode-backup-\d{8}-\d{6}-[0-9a-f]{16,32}\.zip$' -or -not (Test-Path -LiteralPath $full -PathType Leaf)) {throw 'The recorded backup is not a mudmode backup next to your folder; refused. Nothing changed.'}
 if(((Get-Item -LiteralPath $full -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {throw 'Linked backup refused. Nothing changed.'}
 if((Get-MudFileHash $full) -cne [string]$Sha) {throw 'Backup hash does not match the update record; refused. Nothing changed.'}
 $before=Read-MudZip $full; $want=ConvertTo-MudHashTable $Files
 if($before.Count -ne $want.Count) {throw 'Backup contents do not match the update record; refused. Nothing changed.'}
 foreach($k in $before.Keys) { if(-not $want.ContainsKey($k) -or (Get-MudHash $before[$k]) -cne $want[$k]) {throw 'Backup contents do not match the update record; refused. Nothing changed.'} }
 return ,$before
}
function Invoke-MudCrashHook($Point) { if($env:MUDMODE_TESTING -eq '1' -and $env:MUDMODE_TEST_PAUSE -eq $Point) {Write-Host ('TEST PAUSE '+$Point);Start-Sleep -Seconds 60}; if($env:MUDMODE_TESTING -eq '1' -and $env:MUDMODE_TEST_CRASH -eq $Point) {[Environment]::Exit(9)} }   # test-only fault injection
function Write-MudZip($Path,$Map) {
 $f=[IO.File]::Open($Path,[IO.FileMode]::CreateNew); $z=New-Object IO.Compression.ZipArchive($f,[IO.Compression.ZipArchiveMode]::Create)
 try { foreach($p in ($Map.Keys | Sort-Object)) { $e=$z.CreateEntry($p); $s=$e.Open(); try {$s.Write($Map[$p],0,$Map[$p].Length)} finally {$s.Dispose()} } } finally {$z.Dispose();$f.Dispose()}
}
function Read-MudZip($Path,[long]$EntryMax=536870912,[long]$TotalMax=2147483648) {
 $out=@{}; [long]$total=0; $z=[IO.Compression.ZipFile]::OpenRead($Path)
 try { foreach($e in $z.Entries) { $n=$e.FullName; if($out.ContainsKey($n) -or $n.StartsWith('/') -or $n.Contains('\') -or $n.Contains(':') -or (@($n.Split('/') | Where-Object { $_ -eq '' -or $_ -eq '.' -or $_ -eq '..' }).Count)) {throw 'Unsafe or duplicate path in backup'}; $left=$TotalMax-$total; $b=Get-MudEntryBytes $e ([Math]::Min([long]$EntryMax,[long]$left)); $total+=$b.Length; if($total -gt $TotalMax) {throw 'Backup too large'}; $out[$n]=$b } } finally {$z.Dispose()}; return ,$out
}
function Restore-MudSnapshot($Root,$Before) {
 Assert-MudTree $Root; $now=Get-MudSnapshot $Root
 foreach($p in $now.Keys) {if(-not $Before.ContainsKey($p)) {[IO.File]::Delete((Join-Path $Root $p))}}
 foreach($p in $Before.Keys) { $f=Join-Path $Root $p; [IO.Directory]::CreateDirectory((Split-Path -Parent $f)) | Out-Null; [IO.File]::WriteAllBytes($f,$Before[$p]) }
}
function Test-MudConsent($Question,[switch]$Yes) { if($Yes) {return $true}; return ((Read-Host "$Question [y/N]") -ceq 'y') }
# Kit-managed paths (same rules as mudmode.py kit_owned): listed in the installed kit manifest (before or after), the setup
# runtime files, or a .bak-* setup made of one. Everything else (CORE-LOCAL, HANDOFF, LESSONS, JOBS, OK-LEDGER, jobs/, roles/,
# any file you added) is yours and recover/undo never overwrite it.
$script:MudRuntimeFiles=@('SETUP-LOG.md','MODULES-ON.md','tools/.installed-manifest.json','tools/.update-state')
function Get-MudManifestMap($Bytes) { $m=@{}; if($null -eq $Bytes) {return $m}; try {foreach($r in ([Text.Encoding]::UTF8.GetString($Bytes)|ConvertFrom-Json).files) {$m[[string]$r.path]=[string]$r.sha256}} catch {}; return $m }
function Test-MudKitOwned($Path,$Known) {
 if($Path -cmatch '^(.+)\.bak-[A-Za-z0-9-]+$') {$b=$Matches[1];return ($Known.ContainsKey($b) -and -not (Test-MudProtected $b) -and ($b.Split('/')[0]).ToLowerInvariant() -ne 'roles')}
 if((Test-MudProtected $Path) -or ($Path.Split('/')[0]).ToLowerInvariant() -eq 'roles') {return $false}
 return ($Known.ContainsKey($Path) -or $script:MudRuntimeFiles -ccontains $Path)
}
function Get-MudSidePath($Root,$Rel,$Tag,$Stamp) { $q=Join-Path $Root ($Rel+".mudmode-$Tag-$Stamp");$i=1;while(Test-Path -LiteralPath $q) {$q=Join-Path $Root ($Rel+".mudmode-$Tag-$Stamp-$i");$i++};return $q }
function Save-MudSideCopy($Root,$Rel,$Tag,$Stamp,[byte[]]$Bytes) { $q=Get-MudSidePath $Root $Rel $Tag $Stamp;[IO.Directory]::CreateDirectory((Split-Path -Parent $q))|Out-Null;[IO.File]::WriteAllBytes($q,$Bytes);return $q }
function Get-MudChangedOthers($Root,$Hashes) { $bad=@();foreach($p in $Hashes.Keys) {$f=Join-Path $Root $p;if(-not (Test-Path -LiteralPath $f -PathType Leaf) -or (Get-MudFileHash $f) -cne $Hashes[$p]) {$bad+=$p}};return $bad }
# Stage folders: only folders this tool made are removed (marker id = folder id, same kit folder, its process is gone, no links inside).
function Remove-MudOldStages($Root,$KeepName) {
 $parent=Split-Path -Parent $Root;$removed=@()
 foreach($d in [IO.Directory]::GetDirectories($parent,'.mudmode-stage-*')) {
  $name=Split-Path -Leaf $d
  if($name -cnotmatch '^\.mudmode-stage-([0-9a-f]{32})$' -or $name -ceq $KeepName) {continue}
  $id=$Matches[1];$di=New-Object IO.DirectoryInfo $d;if($di.Attributes -band [IO.FileAttributes]::ReparsePoint) {continue}
  $mk=Join-Path $d '.mudmode-stage.json';if(-not [IO.File]::Exists($mk)) {continue}
  $fi=New-Object IO.FileInfo $mk;if(($fi.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $fi.Length -gt 4096) {continue}
  $j=$null;try {$j=[IO.File]::ReadAllText($mk)|ConvertFrom-Json} catch {continue}
  if($null -eq $j -or [string]$j.id -cne $id -or [string]$j.kit -cne $Root -or -not (Test-MudPid $j.pid)) {continue}
  if(Get-Process -Id ([int]$j.pid) -ErrorAction SilentlyContinue) {continue}
  $linked=$false;foreach($x in $di.GetFileSystemInfos('*',[IO.SearchOption]::AllDirectories)) {if($x.Attributes -band [IO.FileAttributes]::ReparsePoint) {$linked=$true;break}};if($linked) {continue}
  [IO.Directory]::Delete($d,$true);$removed+=$name
 }
 if($removed.Count) {Write-Host "Removed $($removed.Count) leftover temporary folder(s) from interrupted updates: $($removed -join ', ')"}
}

# Exact validated markers only; never infer ownership or permission to remove a file from a .tmp suffix.
function Remove-MudAtomicTemps($Root) {
 $parent=Split-Path -Parent $Root;$prefix='.'+(Split-Path -Leaf $Root)+'.mudmode-write-';$pattern='^'+[regex]::Escape($prefix)+'([0-9a-f]{32})\.json$';$removed=@();$known=@{}
 $bp=Join-Path $Root 'tools/.installed-manifest.json';if(Test-Path -LiteralPath $bp -PathType Leaf) {$known=Get-MudManifestMap ([IO.File]::ReadAllBytes($bp))}
 foreach($mk in Get-ChildItem -LiteralPath $parent -Filter ($prefix+'*.json') -File -Force) {
  try {
   if($mk.Name -cnotmatch $pattern -or ($mk.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $mk.Length -gt 4096) {continue};$id=$Matches[1]
   $j=Read-MudJsonSmall $mk.FullName
   if($j.type -cne 'mudmode-atomic-temp-v1' -or $j.id -cne $id -or $j.kit -cne $Root -or -not ($j.target -is [string]) -or -not (Test-MudPid $j.pid)) {continue}
   if(Get-Process -Id ([int]$j.pid) -ErrorAction SilentlyContinue) {continue}
   $n=[string]$j.target;$base=$n;if($n -cmatch '^(.+)\.bak-[A-Za-z0-9-]+$') {$base=$Matches[1]};Assert-MudPath $base
   if(-not (Test-MudKitOwned $n $known)) {continue}
   $tmp=Join-Path $Root ($n+'.tmp-'+$id);$q=$tmp;$linked=$false
   while($q) {if(Test-Path -LiteralPath $q) {if((Get-Item -LiteralPath $q -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {$linked=$true;break}};$next=Split-Path -Parent $q;if($next -eq $q) {break};$q=$next};if($linked) {continue}
   if(Test-Path -LiteralPath $tmp) {if(-not (Test-Path -LiteralPath $tmp -PathType Leaf)) {continue};[IO.File]::Delete($tmp);$removed+=($n+'.tmp-'+$id)}
   [IO.File]::Delete($mk.FullName)
  } catch {continue}
 }
 if($removed.Count) {Write-Host "Removed $($removed.Count) marked kit temporary file(s) from interrupted writes:";foreach($n in $removed) {Write-Host ('   '+$n)}}
}
function Write-MudBackupSummary($Root) {
 # Parent-folder matching backup metadata only, not target-specific ownership; never remove backups, even if old.
 $parent=Split-Path -Parent $Root
 try {$files=@(Get-ChildItem -LiteralPath $parent -File -Force|Where-Object {$_.Name -cmatch '^mudmode-backup-\d{8}-\d{6}-[0-9a-f]{16,32}\.zip$' -and -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint)});[long]$size=0;foreach($f in $files) {$size+=$f.Length};Write-Host "matching backup zips in this parent folder: $($files.Count), $size bytes total.";Write-Host "backup folder: $parent";Write-Host 'this count can include other kits or owner-made matching backups. backups may contain private files. keep any needed for undo or recover. no backups are deleted automatically. any manual removal is your separate choice.'} catch {Write-Host "Could not count backups in $parent. None are deleted automatically."}
}
