#!/usr/bin/env python3
"""Read-only maintainer release gate: every shipped path and file, including tests.
No release/signing authority. Known ordinary drafting/no-send instructions are
allowed only as exact, per-file line hashes; no subtree is excluded.
"""
import argparse, hashlib, re, stat
from pathlib import Path

# Exact existing policy/behavior text, not staging labels. A changed line is rechecked.
ORDINARY_WORD_LINES = {'FOR-CHAT-APPS/mudmode-chat-setup.md': ['2c71a08ae2a9083c42c7ac1309f56b296436eeb75ae9b61025b5ed22c8941879', '91211e24b6285f7c4ab6350387060fc7ef0cae2311fa66f74fe6372a7ab9d179', '9aad8136719711386533c8569f9cd502d7adea14138d3fcb10b97b0655896742', 'f0cee54b8e143d75aba6561910d3a48c1766d298a606cf6a46cce5062b72d47b'], 'MUDMODE.md': ['1a71f2a1f8c2249ac68865098ff610388f291aefd4673ace75c814c1bf95a0bd', '6897ae29663c87c9d209e20a3cb44223e6d21d418e7de5b0da42c0bf5e410461', 'b4bdc2de1b42bac5033e66ab949523b3d2658c76efa5ff40d3b76172eaf34f02', 'bdc92eb2c931e5d8d363a73ad6814b6a59ef8dfca9d2fa11f538fc636b0d6c19', 'e1ada2d0a8e29a0ee7d5f2900284906836ca7269dc4c32e9ed79b2118e6be4f9', 'eacf355b43d5cf8850dab2dd1301967cb729bee11d99397a1da3d5d1d313bb3f', 'fa8cf91a381c27ec963251314099334f0ba4edd62ad9b1841a819b9e95922a76'], 'WHAT-TO-SAY.md': ['4c639c149396deff6e5cb2328d59f5c95542dbfadfe8b7f135743db26d68a812', '83d504857f36ee47b8cb5552259357d198fdd410454aa4f942b96a4f3781e3be', 'd863041c28596b9cfcc38e6db98bdc6614d62a3b64d2c86300f6efd59dd3b1d0', 'f6c1c832bb7fb9eee186245d9a7638697f5fab01f3d03c01062565c37aa1d76b'], 'adapters/CHATGPT.md': ['1a71f2a1f8c2249ac68865098ff610388f291aefd4673ace75c814c1bf95a0bd'], 'adapters/CLAUDE.md': ['1a71f2a1f8c2249ac68865098ff610388f291aefd4673ace75c814c1bf95a0bd'], 'adapters/GROK.md': ['1a71f2a1f8c2249ac68865098ff610388f291aefd4673ace75c814c1bf95a0bd'], 'adapters/OTHER.md': ['1a71f2a1f8c2249ac68865098ff610388f291aefd4673ace75c814c1bf95a0bd'], 'setup/templates/connector-agents.md': ['e30bc8e75dc27831159fedbb02bbc9bffea9a008e586b0992c49da50b6aeeca9'], 'CORE.md': ['3e92f887e3b1d50b410f788ab6ed09688b54fb501daa412aa2090f63e41131a8', '9aad8136719711386533c8569f9cd502d7adea14138d3fcb10b97b0655896742', 'f0cee54b8e143d75aba6561910d3a48c1766d298a606cf6a46cce5062b72d47b'], 'README.md': ['1428d4daf362e2d47957cc3cc2ab04e33d48a59078bf02bbb391da032640749e', '97001087c3206580b0282fc320cc9f8d8bc2da5fec25abc33ce301fd65923a50'], 'adapters/AGENTS.md': ['a5312900bd31eab1bb92e80fddb3e71cbde37b135787370220daedbdf3f105b8'], 'addons/LOCAL-HARDWARE.md': ['712850ebb6d4c436d8d8c3e1004b046257aeeb24e9e3d1950c6b80c3ffc32f2a'], 'templates/DAILY-REPORT.md': ['2c71a08ae2a9083c42c7ac1309f56b296436eeb75ae9b61025b5ed22c8941879'], 'templates/ROLE.md': ['17069ac27f40a15efcbff33fda8687215418c1628b408c4548da6edee4d0950e'], 'templates/SHARED-LESSONS.md': ['68c108f35dfbcf11bb8fae9896f40a4de4a45dac855ede3d69ca6d5fda72bdf4', 'edf4b240e901454a1e0351b3978fda18816ca2c90c9211d35b5822ae2e55fcba', 'f02ad3e1636ed1165005314f1a903c481f11abc10b788ee13accbf9be8f4ee71'], 'tools/claude-hooks/mudmode-guard.mjs': ['1703626f9a4896911ac9b268166b54d23bb57fa451af3176e54de6d9dbff8988'], 'tools/scrub_check.ps1': ['5e857411848b47b484229e8693438dcb5e856004ded8dd1bffb3cde13221a51d'], 'tools/scrub_check.py': ['5e857411848b47b484229e8693438dcb5e856004ded8dd1bffb3cde13221a51d'], 'tools/tests/brief-approved-wording.json': ['27d3835e70bee2aa7d04028e83ddd37c2278f69c0a06a070d7beae23d3ff9ad2', '54617af1aced812c025493126527bc33d9bf824a8c96a43b3aef179c51a64b8b', '620aa58301cd17bfec03f9ec9e6501978522f2d12d314704e732306cfbdaa9c9'], 'tools/tests/test-welcome.py': ['24d0a5c7a7ee4d1069b132acc03202b238a2fcbe9aebff11aae5be19c63640a8', '3628375adc64034462dac8876fa782f82cf2d59758f70c772eab3ae52e107643', '3dce0e9463d8466cf6f66d55fd3f2370b998b52194f341f8082d890e5181312e', 'b421a1bf499001716c6cc23b6f03e70b37bfe20448387f6c9b56347723a2bfcc'], 'FOR-CHAT-APPS/mudmode-chat-lite.md': ['2c71a08ae2a9083c42c7ac1309f56b296436eeb75ae9b61025b5ed22c8941879', '9aad8136719711386533c8569f9cd502d7adea14138d3fcb10b97b0655896742', 'f0cee54b8e143d75aba6561910d3a48c1766d298a606cf6a46cce5062b72d47b', 'f80eabbc5d71bfea08835570f61f3b7fcc10b5fb55eb5ef2462192f5dfc9e201']}
PUBLIC_LOCAL_TEMPLATE_SHA256 = '2aa381398acd7258e35f4b984787c7bffae79085b2a8d6613ac8a328aba560e2'
PUBLIC_POLICY_TEMPLATES = {'setup/templates/CORE-LOCAL.md': '2aa381398acd7258e35f4b984787c7bffae79085b2a8d6613ac8a328aba560e2', 'modules/jobs.md': 'd50c3a2ae5ed4a020d7fe92f289f11ce17f6c5b64f3ad16dab64065038989d97', 'modules/lessons.md': '0cae5710a32bf062e7005a5a0e74920a15d7ea5767b7c6af373a347dd525d26c', 'templates/OK-LEDGER.md': 'f6c6b0d43997e25471f88fd0bcd673822d708bbf7c25c208e2e755c6b147f694', 'templates/JOBS.md': '09304aa5e6350253ee9d2ad32cb71f1a5e710876ec3c42acedb201b26fae5e10', 'templates/LESSONS.md': '2e04a121bc250c521eddd3b88d2f5aa857cd0a8ce70fe8a8dc810824c3cd7b81', 'templates/HANDOFF.md': 'f8087dc18fc0c2586f9dd3cc8fe252e0ace39d771276b39afb511eb41489dd99'}
STAGE_WORD = 'dra' + 'ft'
STAGE_LABEL = 'candi' + 'date'
STAGE_TEXT = re.compile(r'(?i)\b' + STAGE_WORD + r's?\b')
STATUS_TEXT = re.compile(r'(?i)\b' + STAGE_LABEL + r'\b|\bnot[ -]+for[ -]+ship\b|\bnot[ -]+released\b')
OK_ID = re.compile(rb'(?i)(?<![a-z0-9])t[0-9]+(?:u|s[0-9]+)(?![a-z0-9])')
SESSION_ID = re.compile(rb'(?i)\b[0-9]+w\.[0-9]+\b')
HUB_PATH = re.compile(rb'(?i)\bjobs[\\/][^\s\"\'`]+[\\/]build\b')
BOX_PATH = re.compile(rb'(?i)/(?:work' + rb'space|cursor)/[^\s\"\'`]+')
PENDING_LABEL = re.compile(r'(?i)\bpending\s+(?:keeper|brief|review|approval|wording|release)\b')
PATH_STATUS = re.compile(STAGE_WORD+r's?|'+STAGE_LABEL+r'|not[-_ ]+for[-_ ]+ship|not[-_ ]+released',re.I)
PRIVATE_PATH = re.compile(r'(?i)(?:^|[._-])(?:private|backups?|secrets?|credentials?|tokens?)(?:$|[._-])')
KEY_TEXT = [
    re.compile(rb'(?i)npm_[a-z0-9]{20,}'),
    re.compile(rb'(?i)gh[pousr]_[a-z0-9]{20,}'),
    re.compile(rb'(?i)(?:sk-(?:proj-)?|xai-)[a-z0-9_-]{16,}'),
    re.compile(rb'AKIA[A-Z0-9]{16}'),
    re.compile(rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'),
    re.compile(rb'(?i)Bearer[ \t]+[a-z0-9._~+/-]{16,}'),
    re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----'),
    re.compile(rb'(?i)\b(?:api[_-]?key|access[_-]?token|password|secret)\s*[:=]\s*[\"\']?[a-z0-9_+/-]{12,}')
]


def linked(p):
    st=p.lstat()
    return p.is_symlink() or bool(getattr(st,'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',1024))


def nodes(kit):
    pending=[kit]
    while pending:
        folder=pending.pop()
        for p in sorted(folder.iterdir()):
            yield p
            if p.is_dir() and not linked(p):pending.append(p)


def violations(kit):
    bad = []
    if linked(kit):
        return ['root: linked tree not permitted']
    for p in nodes(kit):
        rel = p.relative_to(kit).as_posix(); parts = p.relative_to(kit).parts
        if linked(p):
            bad.append(rel + ': linked artifact'); continue
        try:
            mode = p.stat().st_mode
            if not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
                bad.append(rel + ': non-regular artifact'); continue
            if any(PATH_STATUS.search(part) for part in parts):
                bad.append(rel + ': staging/status path')
            if any(part.lower()=='__pycache__' or re.search(r'(?i)(?:\.bak(?:$|[-.])|\.py[co]$|\.orig$|\.rej$|~$)',part) for part in parts):
                bad.append(rel + ': cache/backup artifact')
            if any(PRIVATE_PATH.search(part) for part in parts):
                bad.append(rel + ': private/backup path')
            if any(part.lower() in ('jobs','handoff','roles','.git','.hg','.svn','.ssh') or part.lower().startswith('.mudmode') for part in parts[:-1] if not p.is_dir()) or (p.is_dir() and p.name.lower() in ('jobs','handoff','roles','.git','.hg','.svn','.ssh')):
                bad.append(rel + ': private working/metadata path')
            if p.is_file():
                lower = p.name.lower()
                if p.stat().st_nlink > 1:bad.append(rel + ': multiply-linked artifact')
                if lower in ('.update-state','.update-state.json','.update-journal') or re.search(r'(?i)(?:^|\.)mudmode-(?:update|undo|submit)-(?:pending|journal|state)(?:\.|$)',lower):
                    bad.append(rel + ': runtime state/journal artifact')
                if lower.startswith(('deny-list','.mudmode')) or lower=='.installed-manifest.json' or re.search(r'(?i)password|passwd|credential|secret|token',lower):
                    bad.append(rel + ': secret-like/private state file')
                if lower.startswith('.env') or lower in ('id_rsa','id_ed25519','id_ecdsa') or p.suffix.lower() in ('.key','.pem','.pfx','.p12','.zip','.tar','.gz','.7z'):
                    bad.append(rel + ': secret-like/archive file')
                data = p.read_bytes()
                if lower in ('core-local.md','handoff.md','lessons.md','jobs.md','ok-ledger.md'):
                    if hashlib.sha256(data).hexdigest()!=PUBLIC_POLICY_TEMPLATES.get(rel):
                        bad.append(rel + ': private working file or changed public policy template')
                if OK_ID.search(data) or SESSION_ID.search(data) or HUB_PATH.search(data) or BOX_PATH.search(data):
                    bad.append(rel + ': internal identifier/private path (value withheld)')
                if any(pattern.search(data) for pattern in KEY_TEXT):
                    bad.append(rel + ': credential-shaped content (value withheld)')
                try:
                    text = data.decode('utf-8')
                except UnicodeDecodeError:
                    bad.append(rel + ': non-UTF8 content cannot be inspected'); continue
                for number,line in enumerate(text.splitlines(),1):
                    if re.search(r'<RELEASE-' + r'DATE>|<LICENSE-' + r'VERSION>|pending;[ ]*not[ ]+yet[ ]+effective',line,re.I):
                        bad.append(f'{rel}:{number}: unresolved freeze metadata')
                    if STATUS_TEXT.search(line) or PENDING_LABEL.search(line):
                        bad.append(f'{rel}:{number}: staging/status content')
                    if STAGE_TEXT.search(line) and hashlib.sha256(line.encode('utf-8')).hexdigest() not in ORDINARY_WORD_LINES.get(rel,[]):
                        bad.append(f'{rel}:{number}: unapproved staging-word content')
        except OSError:
            bad.append(rel + ': inspection failed closed')
    return bad


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--kit',required=True); a=ap.parse_args(); k=Path(a.kit).absolute()
    if not k.is_dir() or not (k/'VERSION').is_file():
        ap.error('--kit must name a kit tree with VERSION')
    bad=violations(k)
    for issue in bad: print('FAIL',issue)
    print('FAIL release gate' if bad else 'PASS release gate: all shipped paths and files inspected')
    raise SystemExit(1 if bad else 0)
