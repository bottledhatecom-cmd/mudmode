# Explicit local signed-pack update. Does not run on startup; no telemetry.
param([string]$Pack='', [string]$Root='', [string]$Url='', [switch]$Yes, [switch]$Undo, [switch]$Recover)
# PS 5.1 can leave `$PSScriptRoot empty in param defaults (seen with a Mandatory param), so set the default here.
if(-not $Root) {$Root=Split-Path -Parent $PSScriptRoot}
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'update-common.ps1')
. (Join-Path $PSScriptRoot 'verify-minisign.ps1')
$work=$null;$script:lock=$null
try {
 $Root=[IO.Path]::GetFullPath($Root).TrimEnd('/','\'); Assert-MudTree $Root
 if($Pack -eq 'undo') {$Undo=$true;$Pack=''}
 if($Pack -eq 'recover') {$Recover=$true;$Pack=''}
 $statePath=Join-Path $Root 'tools/.update-state';$baselinePath=Join-Path $Root 'tools/.installed-manifest.json'
 if(-not (Test-Path (Join-Path $Root 'CORE-LOCAL.md'))) {throw 'Not an installed mudmode folder'}
 $parentDir=Split-Path -Parent $Root;$leaf=Split-Path -Leaf $Root
 $pendingPath=Join-Path $parentDir ('.'+$leaf+'.mudmode-update-pending.json')
 $lockPath=Join-Path $parentDir ('.'+$leaf+'.mudmode-update.lock')
 function Enter-MudUpdateLock {
  # Same rules as mudmode.py: a lock left in the file is stale if older than 6 h, unreadable and older than 60 s, or its process is gone.
  $created=$false
  try {$fs=[IO.File]::Open($lockPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$created=$true} catch [IO.IOException] {
   try {$fs=[IO.File]::Open($lockPath,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)} catch {throw 'Another mudmode update is running or the lock just changed. Try again in a minute. Nothing changed.'}
  }
  try {
   $len=[int][Math]::Min($fs.Length,4096)
   if(-not $created) {
    $buf=New-Object byte[] $len;$null=$fs.Read($buf,0,$len);$raw=[Text.Encoding]::UTF8.GetString($buf,0,$len)
    $lockPid=$null;$invalidPid=$false;try {$j=$raw|ConvertFrom-Json;if(Test-MudPid $j.pid) {$lockPid=[int]$j.pid} elseif(($j.pid -is [int] -or $j.pid -is [long]) -and $j.pid -le 0) {$invalidPid=$true}} catch {}
    $age=([DateTime]::UtcNow-[IO.File]::GetLastWriteTimeUtc($lockPath)).TotalSeconds;$why=$null
    if($invalidPid) {$why='invalid process id'} elseif($age -gt 21600) {$why='older than 6 hours'} elseif($null -eq $lockPid) {if($age -gt 60) {$why='unreadable lock'}} elseif($lockPid -eq $PID -or -not (Get-Process -Id $lockPid -ErrorAction SilentlyContinue)) {$why="process $lockPid is gone"}
    if(-not $why) {if($null -eq $lockPid) {throw "The update lock $lockPath is unreadable and only $([Math]::Floor($age)) seconds old, so another update may be starting. Try again in a minute. Nothing changed."};throw "Another mudmode update is running (pid $lockPid). Wait for it to finish. Nothing changed."}
    Write-Host "Clearing a stale update lock ($why, $([Math]::Floor($age)) seconds old)."
   }
   $b=[Text.Encoding]::UTF8.GetBytes((@{pid=$PID;started=(Get-Date -Format o)}|ConvertTo-Json -Compress));$fs.SetLength(0);$fs.Position=0;$fs.Write($b,0,$b.Length);$fs.Flush()
  } catch {$fs.Dispose();throw}
  $script:lock=$fs;Remove-MudAtomicTemps $Root
 }
 function Assert-MudNoPending {
  if(Test-Path -LiteralPath $pendingPath) {$i=$null;try {$i=Read-MudJsonSmall $pendingPath} catch {};$op='update';if($i.operation -ceq 'undo') {$op='undo'};throw "A previous $op did not finish (started $($i.started), $($i.from_version) to $($i.to_version)). Nothing changed now. Run: powershell -ExecutionPolicy Bypass -File tools\update.ps1 -Recover (it asks, then puts the kit files back from $($i.backup); your own files are kept; any that changed get the backup copy saved beside them)."}
 }
 function Get-MudKnownPaths($BeforeMap) {
  $k=@{};if($BeforeMap -and $BeforeMap.ContainsKey('tools/.installed-manifest.json')) {try {foreach($r in ([Text.Encoding]::UTF8.GetString($BeforeMap['tools/.installed-manifest.json'])|ConvertFrom-Json).files) {$k[$r.path]=$true}} catch {}}
  if(Test-Path -LiteralPath $baselinePath) {try {foreach($r in (Read-MudJsonSmall $baselinePath).files) {$k[$r.path]=$true}} catch {}};return $k
 }
 if($Recover) {
  Enter-MudUpdateLock;Remove-MudOldStages $Root ''
  if(-not (Test-Path -LiteralPath $pendingPath)) {
   $st=$null;try {$st=Read-MudJsonSmall $statePath} catch {}; $bp=$st.backup;if(-not $bp) {$bp=Join-Path $parentDir 'mudmode-backup-*.zip'}
   Write-Host "No pending journal. Kit VERSION: $(([IO.File]::ReadAllText((Join-Path $Root 'VERSION'))).Trim()); last update record: $($st.version); undone: $($st.undone). This does not prove the kit is consistent after an older unjournaled undo. Nothing changed. Backup: $bp. If an undo was interrupted, keep the folder and backup for manual kit-file restoration; do not overwrite your own files.";exit 0
  }
  Write-Host "Recovery journal: $pendingPath. The kit may be mixed until recovery succeeds. Backups: mudmode-backup-*.zip beside $Root."

  $info=Read-MudJsonSmall $pendingPath
  $before=Get-MudCheckedBackup $Root $info.backup $info.backup_sha256 $info.before
  $now=Get-MudSnapshot $Root;$newm=Get-MudManifestMap $now['tools/.installed-manifest.json'];$known=Get-MudManifestMap $before['tools/.installed-manifest.json'];foreach($k in @($newm.Keys)) {$known[$k]=$newm[$k]}
  $restoreList=@($before.Keys|Where-Object {(Test-MudKitOwned $_ $known) -and (-not $now.ContainsKey($_) -or (Get-MudHash $now[$_]) -cne (Get-MudHash $before[$_]))}|Sort-Object)
  $deleteList=@($now.Keys|Where-Object {(-not $before.ContainsKey($_)) -and (Test-MudKitOwned $_ $known)}|Sort-Object)
  # A kit file whose bytes are neither the backup's nor what the update installs may hold your edits: keep a copy.
  $setAside=@(@($restoreList)+@($deleteList)|Where-Object {$now.ContainsKey($_) -and $script:MudRuntimeFiles -cnotcontains $_ -and $_ -cnotmatch '^(.+)\.bak-[A-Za-z0-9-]+$' -and (Get-MudHash $now[$_]) -cne [string]$newm[$_]}|Sort-Object)
  $mineChanged=@($before.Keys|Where-Object {-not (Test-MudKitOwned $_ $known) -and (-not $now.ContainsKey($_) -or (Get-MudHash $now[$_]) -cne (Get-MudHash $before[$_]))}|Sort-Object)
  $others=@{};foreach($p in $now.Keys) {if(-not (Test-MudKitOwned $p $known)) {$others[$p]=Get-MudHash $now[$p]}}
  $op=$info.operation;if(-not $op) {$op='update'};Write-Host "Unfinished $op $($info.from_version) to $($info.to_version). Backup: $($info.backup)"
  Write-Host "Kit files to put back: $($restoreList.Count) | new kit files to remove: $($deleteList.Count) | your files changed since the backup (kept as they are now; the backup copy is saved beside each): $($mineChanged.Count)"
  foreach($p in $restoreList) {Write-Host "   put back: $p"};foreach($p in $deleteList) {Write-Host "   remove: $p"}
  foreach($p in $setAside) {Write-Host "   copy kept first (not the kit version, may hold your edits): $p"};foreach($p in $mineChanged) {Write-Host "   yours, kept as now + backup copy saved beside it: $p"}
  if(-not (Test-MudConsent 'Put the kit back from this backup?' -Yes:$Yes)) {Write-Host 'Cancelled; nothing changed';exit 0}
  $ts=Get-Date -Format 'yyyyMMdd-HHmmss';$saved=@()
  foreach($p in $setAside) {$q=Save-MudSideCopy $Root $p 'yours' $ts $now[$p];$saved+=,@($p,$q,(Get-MudHash $now[$p]),'your copy of it')}
  foreach($p in $mineChanged) {$q=Save-MudSideCopy $Root $p 'recovered' $ts $before[$p];$saved+=,@($p,$q,(Get-MudHash $before[$p]),'backup copy')}
  foreach($p in @($restoreList|Sort-Object @{Expression={$_ -ceq 'VERSION'}},@{Expression={$_}})) {Write-MudBytesAtomic (Join-Path $Root $p) $before[$p] $Root}
  foreach($p in $deleteList) {$f=Join-Path $Root $p;if(Test-Path -LiteralPath $f) {[IO.File]::Delete($f)}}
  $bad=@();foreach($p in $restoreList) {$f=Join-Path $Root $p;if(-not (Test-Path -LiteralPath $f -PathType Leaf) -or (Get-MudHash ([IO.File]::ReadAllBytes($f))) -cne (Get-MudHash $before[$p])) {$bad+=$p}};foreach($p in $deleteList) {if(Test-Path -LiteralPath (Join-Path $Root $p)) {$bad+=$p}}
  foreach($s in $saved) {if((Get-MudFileHash $s[1]) -cne $s[2]) {$bad+=$s[1]}}
  if($bad.Count) {throw "Recover incomplete; these still differ: $(($bad|Select-Object -First 10) -join ', '). The backup is kept at $($info.backup)"}
  $changedMine=@(Get-MudChangedOthers $Root $others)
  if($changedMine.Count) {throw "Recover finished the kit files, but these of your files are not as they were just before recover: $(($changedMine|Select-Object -First 10) -join ', '). The backup is kept at $($info.backup)"}
  [IO.File]::Delete($pendingPath);Write-Host "Recovered: the kit is back to $($info.from_version) from $($info.backup). Your other files ($($others.Count)) were checked by hash after recover: unchanged."
  foreach($s in $saved) {Write-Host "   saved $($s[3]) beside $($s[0]): $($s[1].Substring($Root.Length+1).Replace('\','/'))"};exit 0
 }
 if($Undo) {
  Enter-MudUpdateLock;Assert-MudNoPending
  if(-not (Test-Path -LiteralPath $statePath)) {throw 'No update to undo. Nothing changed.'}
  $state=Read-MudJsonSmall $statePath
  if($state.format -ne 2 -or $null -eq $state.version -or $null -eq $state.version_before -or -not $state.backup -or -not $state.backup_sha256 -or $null -eq $state.backup_files -or $null -eq $state.changed) {throw 'The update record has an unsupported format or is incomplete, so undo is refused. Nothing changed. Your backup zip is next to your mudmode folder.'}
  if($state.undone) {Write-Host 'The last update was already undone. Nothing changed.';exit 0}
  $cur=([IO.File]::ReadAllText((Join-Path $Root 'VERSION'))).Trim()
  if($cur -cne [string]$state.version) {throw "Your kit is at $cur, but the last update was to $($state.version), so undo is refused. Nothing changed. The kit may be mixed after an older unjournaled undo; backup: $($state.backup). Keep it for manual kit-file restoration."}
  $before=Get-MudCheckedBackup $Root $state.backup $state.backup_sha256 $state.backup_files
  if(-not $before.ContainsKey('VERSION') -or ([Text.Encoding]::UTF8.GetString($before['VERSION'])).Trim() -cne [string]$state.version_before) {throw 'The backup is not from the version before the update; refused. Nothing changed.'}
  $now=Get-MudSnapshot $Root;$restore=@();$keptLater=@();$owned=Get-MudManifestMap $before['tools/.installed-manifest.json'];$nm=Get-MudManifestMap $now['tools/.installed-manifest.json'];foreach($p in $nm.Keys) {$owned[$p]=$nm[$p]}
  foreach($r in $state.changed) {if($r.generated_backup) {if($r.path -notmatch '^(.+)\.bak-[A-Za-z0-9-]+$') {throw 'Invalid generated backup'};Assert-MudPath $Matches[1]} else {Assert-MudPath $r.path; if(Test-MudProtected $r.path) {continue}}; if(-not (Test-MudKitOwned $r.path $owned)) {continue}; $h='';if($now.ContainsKey($r.path)) {$h=Get-MudHash $now[$r.path]}; if($h -ne $r.after) {$keptLater+=$r.path;continue}; $restore+=,$r.path}
  foreach($p in $keptLater) {Write-Host "   changed since the update, kept as it is now: $p"}
  $sel=@{};foreach($p in $restore) {$sel[$p]=$true};$others=@{};foreach($p in $now.Keys) {if(-not $sel.ContainsKey($p)) {$others[$p]=Get-MudHash $now[$p]}}
  if(-not (Test-MudConsent 'Undo these kit changes?' -Yes:$Yes)) {Write-Host 'Cancelled; nothing changed';exit 0}
  # Journal before the first file change; recover rolls undo back to the pre-undo kit, retaining the original backup.
  $ub=Join-Path $parentDir ('mudmode-backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N')+'.zip');Write-MudZip $ub $now
  $uh=@{};foreach($p in $now.Keys) {$uh[$p]=Get-MudHash $now[$p]}
  Write-MudTextAtomic $pendingPath (@{format=1;operation='undo';started=(Get-Date -Format o);pid=$PID;from_version=$cur;to_version=$state.version_before;backup=$ub;backup_sha256=(Get-MudFileHash $ub);before=$uh}|ConvertTo-Json -Depth 10)
  Invoke-MudCrashHook 'undo-journal'
  $ts=Get-Date -Format 'yyyyMMdd-HHmmss';$saved=@()
  foreach($p in $keptLater) {if($before.ContainsKey($p) -and (-not $now.ContainsKey($p) -or (Get-MudHash $now[$p]) -cne (Get-MudHash $before[$p]))) {$q=Save-MudSideCopy $Root $p 'recovered' $ts $before[$p];$saved+=,@($p,$q,(Get-MudHash $before[$p]))}}
  $ix=0;foreach($p in @($restore|Sort-Object @{Expression={$_ -ceq 'VERSION'}},@{Expression={$_}})) {
   $f=Join-Path $Root $p;if($p -ceq 'VERSION') {Invoke-MudCrashHook 'undo-before-version'}
   if($before.ContainsKey($p)) {Write-MudBytesAtomic $f $before[$p] $Root} elseif(Test-Path -LiteralPath $f) {[IO.File]::Delete($f)}
   if($ix -eq 0) {Invoke-MudCrashHook 'undo-first-file'};if($ix -eq [Math]::Floor($restore.Count/2)) {Invoke-MudCrashHook 'undo-mid-files'};$ix++
  }
  Invoke-MudCrashHook 'undo-after-files'
  $bad=@();foreach($p in $restore) {$f=Join-Path $Root $p;if($before.ContainsKey($p)) {if(-not (Test-Path -LiteralPath $f -PathType Leaf) -or (Get-MudHash ([IO.File]::ReadAllBytes($f))) -cne (Get-MudHash $before[$p])) {$bad+=$p}} elseif(Test-Path -LiteralPath $f) {$bad+=$p}}
  foreach($s in $saved) {if((Get-MudFileHash $s[1]) -cne $s[2]) {$bad+=$s[1]}};$bad+=@(Get-MudChangedOthers $Root $others)
  if($bad.Count) {throw "Undo incomplete; these files did not come back: $(($bad|Select-Object -First 10) -join ', '). The update record is unchanged; the backup is kept at $($state.backup)"}
  # Serial high-water mark is deliberately retained on undo to prevent replay.
  $state.undone=$true;Write-MudTextAtomic $statePath ($state|ConvertTo-Json -Depth 10) $Root
  Invoke-MudCrashHook 'undo-after-state'
  [IO.File]::Delete($pendingPath)
  $msg="Undo complete: the kit is back to $(([IO.File]::ReadAllText((Join-Path $Root 'VERSION'))).Trim()) from $($state.backup); replay high-water mark retained.";if($keptLater.Count) {$msg+=" Kept your later edits: $($keptLater -join ', ')."};$msg+=" Your other files ($($others.Count)) were checked by hash after undo: unchanged.";Write-Host $msg;Write-MudBackupSummary $Root
  foreach($s in $saved) {Write-Host "   saved backup copy beside $($s[0]): $($s[1].Substring($Root.Length+1).Replace('\','/'))"};exit 0
 }
 if(Test-Path -LiteralPath $pendingPath) {Enter-MudUpdateLock;Assert-MudNoPending}
 if(-not $Pack -and -not $Url) {if(-not $script:lock) {Enter-MudUpdateLock};Write-Host 'No download. Crew: planned https://mudmodecrew.com/updates/crew/<ver>/pack.zip; hosting unproven. Pass -Url explicitly, or -Pack FILE.';exit 0}
 $kind='crew';if(Test-Path (Join-Path $Root 'full-kit')) {$kind='full'}
 $stageId=[Guid]::NewGuid().ToString('N');$work=Join-Path (Split-Path -Parent $Root) ('.mudmode-stage-'+$stageId);[IO.Directory]::CreateDirectory($work)|Out-Null
 Write-MudText (Join-Path $work '.mudmode-stage.json') (@{format=1;id=$stageId;kit=$Root;pid=$PID;created=(Get-Date -Format o)}|ConvertTo-Json -Compress)
 if($Url) {
  if($kind -eq 'full') {throw 'Full Kit only accepts a local Gumroad pack'}
  $u=[Uri]$Url;if($u.UserInfo -or ($u.Scheme -ne 'https' -and -not ($env:MUDMODE_TESTING -eq '1' -and $u.IsLoopback -and $u.Scheme -eq 'http'))) {throw 'HTTPS URL required'}
  $req=[Net.HttpWebRequest]::Create($u);$req.UserAgent='mudmode-update';$req.Timeout=15000;$req.AllowAutoRedirect=$false;$req.CookieContainer=$null
  $resp=$req.GetResponse();try {if([int]$resp.StatusCode -ne 200) {throw 'Download failed'};$s=$resp.GetResponseStream();$f=[IO.File]::Create((Join-Path $work 'pack.zip'));try {$buf=New-Object byte[] 65536;$total=0;while(($n=$s.Read($buf,0,$buf.Length)) -gt 0) {$total+=$n;if($total -gt 67108864) {throw 'Pack too large'};$f.Write($buf,0,$n)}} finally {$s.Dispose();$f.Dispose()}} finally {$resp.Dispose()};$Pack=Join-Path $work 'pack.zip'
 }
 if((Get-Item -LiteralPath $Pack).Length -gt 67108864) {throw 'Pack too large'}
 $z=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($Pack));$payload=@{}
 try {
  $entries=@{};$total=0
  foreach($e in $z.Entries) {if($e.FullName.EndsWith('/')) {throw 'Directory entries not allowed'};Assert-MudPath $e.FullName;if($e.FullName -in @('tools/.update-state','tools/.installed-manifest.json')) {throw 'Runtime metadata in pack'};if($entries.ContainsKey($e.FullName)) {throw 'Duplicate/case-colliding path'};if($e.Length -gt 33554432) {throw 'File too large'};$total+=$e.Length;if($total -gt 268435456) {throw 'Unpacked size limit'};$entries[$e.FullName]=$e}
  if(-not $entries.ContainsKey('manifest.json') -or -not $entries.ContainsKey('manifest.json.minisig')) {throw 'Missing signed manifest'}
  if($entries['manifest.json'].Length -gt 1048576 -or $entries['manifest.json.minisig'].Length -gt 4096) {throw 'Manifest size limit'}
  $data=Get-MudEntryBytes $entries['manifest.json'] 1048576;$sig=[Text.Encoding]::UTF8.GetString((Get-MudEntryBytes $entries['manifest.json.minisig'] 4096)).TrimEnd("`r","`n") -split '\r?\n'
  $keyLines=@(Get-Content -LiteralPath (Join-Path $Root 'tools/update-key.pub'));if($keyLines.Count -ne 2 -or $keyLines[0] -cnotmatch '^untrusted comment: minisign public key [0-9A-F]{16}$' -or $keyLines[1] -cne $script:MudPinnedKey) {throw 'Pinned key mismatch'}
  $keyRaw=[Convert]::FromBase64String($keyLines[1]);$keyID=(($keyRaw[9..2]|ForEach-Object {$_.ToString('X2')}) -join '');if(-not $keyLines[0].EndsWith(' '+$keyID)) {throw 'Key header mismatch'}
  $result=Invoke-MudMinisignVerify $keyLines[1] $sig $data;if(-not $result.StartsWith('OK: ')) {throw "Signature failed: $result"}
  $m=[Text.Encoding]::UTF8.GetString($data) | ConvertFrom-Json
  if($m.format -ne 1 -or $m.kit -cne $kind -or $m.version -notmatch '^\d+\.\d+\.\d+$' -or $m.min_from -notmatch '^\d+\.\d+\.\d+$' -or $m.serial -isnot [ValueType] -or [double]$m.serial -ne [long]$m.serial -or [long]$m.serial -lt 1) {throw 'Invalid manifest schema/kit'}
  $comment="mudmode $($m.kit) $($m.version) serial $($m.serial) sha256 $(Get-MudHash $data)";if($result -cne "OK: $comment") {throw 'Trusted comment mismatch'}
  $current=([IO.File]::ReadAllText((Join-Path $Root 'VERSION'))).Trim();if([version]$m.version -le [version]$current -or [version]$current -lt [version]$m.min_from) {throw 'Older version or unsupported base refused'}
  if(Test-Path $statePath) {$old=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json;if([long]$m.serial -le [long]$old.serial) {throw 'Older release serial refused'}}
  $seen=@{};foreach($r in $m.files) {Assert-MudPath $r.path;if($r.path -in @('manifest.json','manifest.json.minisig') -or $seen.ContainsKey($r.path) -or $r.sha256 -notmatch '^[0-9a-f]{64}$' -or $r.size -lt 0 -or $r.size -gt 33554432) {throw 'Invalid file record'};$seen[$r.path]=$true;if(-not $entries.ContainsKey($r.path)) {throw 'Missing pack file'};$b=Get-MudEntryBytes $entries[$r.path];if($b.Length -ne $r.size -or (Get-MudHash $b) -cne $r.sha256) {throw 'Tampered pack file'};$payload[$r.path]=$b}
  if($entries.Count -ne $seen.Count+2) {throw 'Extra file in pack'}
  if(-not $payload.ContainsKey('VERSION') -or [Text.Encoding]::UTF8.GetString($payload['VERSION']).Trim() -cne $m.version) {throw 'Payload VERSION mismatch'}
  if($m.setup -cne 'setup/setup.ps1' -or -not $payload.ContainsKey($m.setup)) {throw 'Invalid setup entry'}
 } finally {$z.Dispose()}
 foreach($p in $payload.Keys) {$f=Join-Path $work $p;[IO.Directory]::CreateDirectory((Split-Path -Parent $f))|Out-Null;[IO.File]::WriteAllBytes($f,$payload[$p])}
 # Exclusive lock and recheck state before any target write. Lock lives beside target, not within it.
 if(-not $script:lock) {Enter-MudUpdateLock};Assert-MudNoPending;Remove-MudOldStages $Root (Split-Path -Leaf $work)
 Assert-MudTree $Root
 $lockedCurrent=([IO.File]::ReadAllText((Join-Path $Root 'VERSION'))).Trim()
 if([version]$m.version -le [version]$lockedCurrent) {throw 'Version changed while waiting for lock'}
 if(Test-Path $statePath) {$lockedState=Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json;if([long]$m.serial -le [long]$lockedState.serial) {throw 'Serial changed while waiting for lock'}}
 $exe=(Get-Process -Id $PID).Path;$setup=Join-Path $work 'setup/setup.ps1'
 & $exe -NoProfile -ExecutionPolicy Bypass -File $setup -Target $Root -Connect none -AllowDir no -LocalOnly -Yes -DryRun
 if($LASTEXITCODE -ne 0) {throw 'Setup dry run failed'}
 if(-not (Test-MudConsent 'Apply verified update?' -Yes:$Yes)) {Write-Host 'Cancelled; nothing changed';exit 0}
 $before=Get-MudSnapshot $Root
 $backup=Join-Path (Split-Path -Parent $Root) ('mudmode-backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N')+'.zip')
 $bytes=0;foreach($v in $before.Values) {$bytes+=$v.Length};$drive=New-Object IO.DriveInfo ([IO.Path]::GetPathRoot($Root));if($drive.AvailableFreeSpace -lt (3*$bytes+2*$total+10485760)) {throw 'Insufficient free space'}
 Write-MudZip $backup $before
 $hashes=@{};foreach($p in $before.Keys) {$hashes[$p]=Get-MudHash $before[$p]};$backupSha=Get-MudFileHash $backup
 # Journal first: if this run is killed, the next run sees it and offers -Recover from this backup.
 Write-MudTextAtomic $pendingPath (@{format=1;started=(Get-Date -Format o);pid=$PID;from_version=$lockedCurrent;to_version=$m.version;serial=$m.serial;backup=$backup;backup_sha256=$backupSha;before=$hashes}|ConvertTo-Json -Depth 10)
 try {
  Invoke-MudCrashHook 'before-setup'
  & $exe -NoProfile -ExecutionPolicy Bypass -File $setup -Target $Root -Connect none -AllowDir no -LocalOnly -Yes
  if($LASTEXITCODE -ne 0) {throw 'Setup failed'}
  Invoke-MudCrashHook 'after-setup'
  $after=Get-MudSnapshot $Root
  $known=@{};if($before.ContainsKey('tools/.installed-manifest.json')) {$oldBase=[Text.Encoding]::UTF8.GetString($before['tools/.installed-manifest.json'])|ConvertFrom-Json;foreach($r in $oldBase.files) {$known[$r.path]=$true}}
  $newBase=Get-Content -LiteralPath $baselinePath -Raw|ConvertFrom-Json;foreach($r in $newBase.files) {$known[$r.path]=$true}
  foreach($p in $before.Keys) {if((Test-MudProtected $p) -or (-not $known.ContainsKey($p) -and $p -notin @('SETUP-LOG.md','MODULES-ON.md','tools/.installed-manifest.json','tools/.update-state'))) {if(-not $after.ContainsKey($p) -or (Get-MudHash $before[$p]) -ne (Get-MudHash $after[$p])) {throw 'User file changed; restoring snapshot'}}}
  $changed=@();foreach($p in $after.Keys) {$generated=$false;if($p -match '^(.+)\.bak-[A-Za-z0-9-]+$' -and -not $before.ContainsKey($p) -and $known.ContainsKey($Matches[1]) -and -not (Test-MudProtected $Matches[1])) {$generated=$true};if($p -eq 'tools/.update-state' -or ((Test-MudProtected $p) -and -not $generated)) {continue};$h=Get-MudHash $after[$p];if(-not $before.ContainsKey($p) -or (Get-MudHash $before[$p]) -ne $h) {$changed+=@{path=$p;after=$h;generated_backup=$generated}}}
  Write-MudTextAtomic $statePath (@{format=2;serial=$m.serial;version=$m.version;version_before=$lockedCurrent;backup=$backup;backup_sha256=$backupSha;backup_files=$hashes;changed=$changed;undone=$false}|ConvertTo-Json -Depth 10) $Root
 } catch {Restore-MudSnapshot $Root $before;if(Test-Path -LiteralPath $pendingPath) {[IO.File]::Delete($pendingPath)};throw}
 [IO.File]::Delete($pendingPath)
 Write-Host "Updated. Backup: $backup";Write-MudBackupSummary $Root
} catch {Write-Error "Update stopped: $($_.Exception.Message)" -ErrorAction Continue;exit 1}
finally {if($script:lock) {$script:lock.Dispose();if(Test-Path -LiteralPath $lockPath) {[IO.File]::Delete($lockPath)}};if($work -and (Test-Path -LiteralPath $work)) {Remove-Item -LiteralPath $work -Recurse -Force}}
