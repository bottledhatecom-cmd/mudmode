#!/usr/bin/env python3
"""Stdlib POSIX coordinator. Requires Python 3 + minisign or OpenSSL 3.
No scheduler or startup action. Crew update-only build; no submit command is included.
"""
import argparse, base64, contextlib, hashlib, io, json, os, pathlib, re, shutil, subprocess, sys, tempfile, time, zipfile
P = pathlib.Path
PINNED = 'RWTSpU4Hr4bBpWocWhRC1lvgdmQkJ1mTFCSovtzIz0C6t281SJS3ej72'
MAX_PACK=64*1024*1024
PROTECTED=re.compile(r'^(core-local\.md|handoff(?:\.md|/|$)|lessons\.md|jobs(?:\.md|/|$)|ok-ledger\.md)$|^(jobs|handoff)/|\.bak-|(^|/)[^/]*(password|passwd|credential|secret|token)[^/]*$|(^|/)(deny-list[^/]*|[^/]*\.private(?:\.[^/]*)?|\.env[^/]*|[^/]*\.(pem|key|pfx|p12)|id_rsa|credentials[^/]*|secrets?[^/]*)$',re.I)
def protected(s): return bool(PROTECTED.search(s))
def safe(s):
    if not isinstance(s,str) or len(s)>220 or not re.fullmatch(r'[A-Za-z0-9_(). -]+(/[A-Za-z0-9_(). -]+)*',s): raise ValueError('Unsafe path')
    if any(x in ('.','..') or x.endswith(('.',' ')) or re.match(r'^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\.|$)',x,re.I) for x in s.split('/')) or protected(s): raise ValueError('Personal/unsafe path')
    return s

def digest(b): return hashlib.sha256(b).hexdigest()
def write_json(p,obj): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf8')
def tree_safe(root):
    if any(p.is_symlink() for p in (root,*root.parents)): raise ValueError('Linked root/ancestor refused')
    for d,ds,fs in os.walk(root,followlinks=False):
        if any((P(d)/x).is_symlink() for x in ds+fs): raise ValueError('Links refused')
def snapshot(root):
    tree_safe(root);return {p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}
def writezip(p,files):
    with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for n,b in sorted(files.items()): z.writestr(n,b)
def restore(root,files):
    tree_safe(root)
    for p in root.rglob('*'):
        if p.is_file() and p.relative_to(root).as_posix() not in files: p.unlink()
    for n,b in files.items(): p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
ENTRY_MAX=32*1024*1024; TOTAL_MAX=256*1024*1024; RATIO_MAX=250
def read_entry(z,info,limit=ENTRY_MAX):
    """Read one zip entry with a hard cap on the bytes really inflated (never trust the header alone)."""
    if info.file_size>limit:raise ValueError('Zip entry larger than allowed: '+info.filename)
    if info.file_size>1024*1024 and info.compress_size and info.file_size/info.compress_size>RATIO_MAX:raise ValueError('Zip entry compression ratio too high: '+info.filename)
    cap=info.file_size;out=bytearray()
    try:
        with z.open(info) as f:
            while True:
                chunk=f.read(65536)
                if not chunk:break
                out+=chunk
                if len(out)>cap:raise ValueError('Zip entry is bigger than its header says; refused: '+info.filename)
    except zipfile.BadZipFile as e:raise ValueError('Zip entry is bigger than its header says, or damaged; refused: '+info.filename) from e
    if len(out)!=cap:raise ValueError('Zip entry size does not match its header: '+info.filename)
    return bytes(out)
def read_zip(path,entry_max=512*1024*1024,total_max=2*1024*1024*1024):
    out={};total=0
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            n=info.filename
            if n in out or n.startswith('/') or '\\' in n or ':' in n or any(c in ('','.','..') for c in n.split('/')):raise ValueError('Unsafe or duplicate path in backup')
            if info.file_size>total_max-total:raise ValueError('Backup too large')
            b=read_entry(z,info,min(entry_max,total_max-total));total+=len(b)
            if total>total_max:raise ValueError('Backup too large')
            out[n]=b
    return out
def file_sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()
def write_json_atomic(p,obj,root=None):
    write_bytes_atomic(p,(json.dumps(obj,indent=2)+'\n').encode('utf8'),root)
def write_bytes_atomic(p,data,root=None):
    p.parent.mkdir(parents=True,exist_ok=True)
    ident=os.urandom(16).hex();tmp=p.with_name(p.name+'.tmp-'+ident);marker=None
    if root is not None:
        rel=p.relative_to(root).as_posix()
        marker=root.parent/('.'+root.name+'.mudmode-write-'+ident+'.json')
        with marker.open('x',encoding='utf8') as f:json.dump(dict(type='mudmode-atomic-temp-v1',id=ident,kit=kit_id(root),target=rel,pid=os.getpid()),f)
    # CreateNew prevents accidentally overwriting another file, even with a name collision.
    with tmp.open('xb') as f:
        cut=min(1024,len(data));f.write(data[:cut]);f.flush()
        if marker is not None:crash_hook('atomic-temp-written')
        f.write(data[cut:])
    os.replace(tmp,p)
    if marker is not None:marker.unlink()
def read_json_small(p,limit=16*1024*1024):
    if p.stat().st_size>limit:raise ValueError('Record file too large: '+p.name)
    return json.loads(p.read_text(encoding='utf8'))
BACKUP_NAME=re.compile(r'mudmode-backup-\d{8}-\d{6}-[0-9a-f]{16,32}\.zip')
def check_backup(root,path,sha,files):
    """The backup must be a mudmode backup next to the folder, match its recorded hash, and hold exactly the recorded files."""
    b=P(str(path))
    if not isinstance(files,dict) or not isinstance(sha,str):raise ValueError('Update record has no backup hashes; refused. Nothing changed.')
    if b.is_symlink() or not b.is_file() or b.parent.resolve()!=root.parent.resolve() or not BACKUP_NAME.fullmatch(b.name):raise ValueError('The recorded backup is not a mudmode backup next to your folder; refused. Nothing changed.')
    if file_sha(b)!=sha:raise ValueError('Backup hash does not match the update record; refused. Nothing changed.')
    before=read_zip(b)
    if {n:digest(v) for n,v in before.items()}!=files:raise ValueError('Backup contents do not match the update record; refused. Nothing changed.')
    return before
LOCK_STALE=6*3600; LOCK_UNREADABLE_GRACE=60
def pid_alive(pid):
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False
    except PermissionError:return True
    except Exception:return False
def clear_lock(lock,seen):
    """Move the stale lock aside, then check it is the same file we judged stale (not a new lock another run just took)."""
    tmp=lock.with_name(lock.name+'.stale-'+os.urandom(6).hex())
    try:os.rename(lock,tmp)
    except FileNotFoundError:return
    now=tmp.stat()
    if (now.st_ino,now.st_mtime_ns,now.st_size)!=(seen.st_ino,seen.st_mtime_ns,seen.st_size):
        with contextlib.suppress(OSError):os.link(tmp,lock)
        tmp.unlink();raise ValueError('Another mudmode update took the lock just now. Nothing changed.')
    tmp.unlink()
def lock_verdict(raw,age,own_pid):
    """Same rules in update.ps1: stale if older than 6 h, unreadable and older than 60 s, or its process is gone."""
    info=None
    with contextlib.suppress(Exception):info=json.loads(raw)
    pid=info.get('pid') if isinstance(info,dict) and type(info.get('pid')) is int else None
    if pid is not None and pid<=0:return pid,'invalid process id'
    if pid is not None and pid>2147483647:pid=None
    if age>LOCK_STALE:return pid,f'older than {LOCK_STALE//3600} hours'
    if pid is None:return None,('unreadable lock' if age>LOCK_UNREADABLE_GRACE else None)
    if pid==own_pid or not pid_alive(pid):return pid,f'process {pid} is gone'
    return pid,None
@contextlib.contextmanager
def update_lock(root):
    lock=root.parent/('.'+root.name+'.mudmode-update.lock')
    for attempt in (1,2,3):
        try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);break
        except FileExistsError:
            try:seen=lock.stat()
            except FileNotFoundError:continue
            raw=''
            with contextlib.suppress(Exception):raw=lock.read_bytes()[:4096].decode('utf8','replace')
            age=time.time()-seen.st_mtime;pid,why=lock_verdict(raw,age,os.getpid())
            if why and attempt<3:
                print(f'Clearing a stale update lock ({why}, {int(age)} seconds old).');clear_lock(lock,seen);continue
            if pid is None:raise ValueError(f'The update lock {lock} is unreadable and only {int(age)} seconds old, so another update may be starting. Try again in a minute. Nothing changed.')
            raise ValueError(f'Another mudmode update is running (pid {pid}). Wait for it to finish. If none is running, the lock clears itself after {LOCK_STALE//3600} hours, or delete {lock}. Nothing changed.')
    else:raise ValueError('Could not take the update lock. Nothing changed.')
    try:
        os.write(fd,json.dumps(dict(pid=os.getpid(),started=time.time())).encode());clean_atomic_temps(root);yield
    finally:
        os.close(fd)
        with contextlib.suppress(FileNotFoundError):lock.unlink()
# ---- stage folders (N2): only folders this tool made (marker id = folder id, same kit, dead pid) are removed.
STAGE=re.compile(r'\.mudmode-stage-([0-9a-f]{32})');STAGE_MARK='.mudmode-stage.json'
def kit_id(root):return os.path.abspath(str(root))
@contextlib.contextmanager
def stage_dir(root):
    sid=os.urandom(16).hex();d=root.parent/('.mudmode-stage-'+sid);d.mkdir(mode=0o700)
    try:
        (d/STAGE_MARK).write_text(json.dumps(dict(format=1,id=sid,kit=kit_id(root),pid=os.getpid(),created=time.time())),encoding='utf8');yield str(d)
    finally:shutil.rmtree(d,ignore_errors=True)
def clean_stages(root,keep=''):
    removed=[]
    for d in sorted(root.parent.iterdir()):
        m=STAGE.fullmatch(d.name)
        if not m or d.name==keep or d.is_symlink() or not d.is_dir():continue
        mk=d/STAGE_MARK
        try:
            if mk.is_symlink() or not mk.is_file() or mk.stat().st_size>4096:continue
            info=json.loads(mk.read_text(encoding='utf8'))
        except Exception:continue
        if not isinstance(info,dict) or info.get('id')!=m[1] or info.get('kit')!=kit_id(root) or type(info.get('pid')) is not int or not 0<info['pid']<=2147483647 or pid_alive(info['pid']):continue
        if any(os.path.islink(os.path.join(w,x)) for w,ds,fs in os.walk(d) for x in ds+fs):continue
        shutil.rmtree(d);removed.append(d.name)
    if removed:print(f'Removed {len(removed)} leftover temporary folder(s) from interrupted updates:',', '.join(removed))
    return removed
def pending_path(root):return root.parent/('.'+root.name+'.mudmode-update-pending.json')
def refuse_if_pending(root):
    pp=pending_path(root)
    if pp.exists():
        info={}
        with contextlib.suppress(Exception):info=read_json_small(pp)
        op='undo' if info.get('operation')=='undo' else 'update'
        raise ValueError(f"A previous {op} did not finish (started {info.get('started','?')}, {info.get('from_version','?')} to {info.get('to_version','?')}). Nothing changed now. Run: sh tools/update.sh recover  (it asks, then puts the kit files back from {info.get('backup','the backup zip')}; your own files are kept; any that changed get the backup copy saved beside them).")
RUNTIME={'SETUP-LOG.md','MODULES-ON.md','tools/.installed-manifest.json','tools/.update-state'}
GENERATED=re.compile(r'(.+)\.bak-[A-Za-z0-9-]+')
def manifest_map(raw):
    try:return {r['path']:r.get('sha256') for r in json.loads(raw)['files']}
    except Exception:return {}
def kit_owned(n,known):
    """Kit-managed: listed in the installed kit manifest (before or after), the setup runtime files, or a .bak-* setup made of one.
    Everything else (CORE-LOCAL, HANDOFF, LESSONS, JOBS, OK-LEDGER, jobs/, roles/, any file you added) is yours and is never overwritten."""
    mat=GENERATED.fullmatch(n)
    if mat:return mat[1] in known and not protected(mat[1]) and mat[1].split('/')[0].lower()!='roles'
    if protected(n) or n.split('/')[0].lower()=='roles':return False
    return n in known or n in RUNTIME
def clean_atomic_temps(root):
    """Only exact, marked kit-file temps from a dead writer. Unmarked/legacy temps are never guessed at."""
    known=manifest_map((root/'tools/.installed-manifest.json').read_bytes()) if (root/'tools/.installed-manifest.json').is_file() else {}
    pat=re.compile(re.escape('.'+root.name+'.mudmode-write-')+r'([0-9a-f]{32})\.json');removed=[]
    for mk in root.parent.iterdir():
        mat=pat.fullmatch(mk.name)
        if not mat:continue
        try:
            if mk.is_symlink() or not mk.is_file() or mk.stat().st_size>4096:continue
            j=read_json_small(mk,4096)
            if not isinstance(j,dict) or j.get('type')!='mudmode-atomic-temp-v1' or j.get('id')!=mat[1] or j.get('kit')!=kit_id(root):continue
            pid=j.get('pid');n=j.get('target')
            if type(pid) is not int or not 0<pid<=2147483647 or pid_alive(pid) or not isinstance(n,str):continue
            gen=GENERATED.fullmatch(n);safe(gen[1] if gen else n)
            if not kit_owned(n,known):continue
            tmp=root/(n+'.tmp-'+mat[1])
            # Check every ancestor; never traverse a link or remove a linked file/folder.
            if any(q.is_symlink() for q in [tmp,*tmp.parents]):continue
            if tmp.exists():
                if not tmp.is_file():continue
                tmp.unlink();removed.append(tmp.relative_to(root).as_posix())
            mk.unlink()
        except (OSError,ValueError,TypeError,KeyError):continue
    if removed:
        print(f'Removed {len(removed)} marked kit temporary file(s) from interrupted writes:')
        for n in removed:print('   '+n)
    return removed
def backup_summary(root):
    # Count matching regular, non-linked backup zips in the parent folder, not just this kit; never delete any.
    try:
        files=[p for p in root.parent.iterdir() if BACKUP_NAME.fullmatch(p.name) and not p.is_symlink() and p.is_file()]
        size=sum(p.stat().st_size for p in files)
        print(f'matching backup zips in this parent folder: {len(files)}, {size} bytes total.')
        print('backup folder: '+str(root.parent))
        print('this count can include other kits or owner-made matching backups. backups may contain private files. keep any needed for undo or recover. no backups are deleted automatically. any manual removal is your separate choice.')
    except OSError:print('Could not count backups in '+str(root.parent)+'. None are deleted automatically.')
def side_path(root,n,tag,ts):
    q=root/(n+f'.mudmode-{tag}-{ts}');i=1
    while q.exists() or q.is_symlink():q=root/(n+f'.mudmode-{tag}-{ts}-{i}');i+=1
    return q
def check_others(root,hashes):
    return [n for n,h in hashes.items() if (root/n).is_symlink() or not (root/n).is_file() or file_sha(root/n)!=h]
def crash_hook(point):
    if os.environ.get('MUDMODE_TESTING')=='1' and os.environ.get('MUDMODE_TEST_PAUSE')==point:print('TEST PAUSE '+point,flush=True);time.sleep(60)
    if os.environ.get('MUDMODE_TESTING')=='1' and os.environ.get('MUDMODE_TEST_CRASH')==point:os._exit(9)   # test-only fault injection
def kit_version(root):return (root/'VERSION').read_text().strip()

def recover(root,args):
    with update_lock(root):
        clean_stages(root)
        pp=pending_path(root)
        if not pp.exists():
            st={}
            with contextlib.suppress(Exception):st=read_json_small(root/'tools/.update-state')
            print(f"No pending journal. Kit VERSION: {kit_version(root)}; last update record: {st.get('version','unknown')}; undone: {st.get('undone','unknown')}. This does not prove the kit is consistent after an older unjournaled undo. Nothing changed. Backup: {st.get('backup','mudmode-backup-*.zip beside '+str(root))}. If an undo was interrupted, keep the folder and backup for manual kit-file restoration; do not overwrite your own files.");return
        print(f'Recovery journal: {pp}. The kit may be mixed until recovery succeeds. Backups: mudmode-backup-*.zip beside {root}.')
        info=read_json_small(pp)
        before=check_backup(root,info.get('backup',''),info.get('backup_sha256'),info.get('before'))
        now=snapshot(root);newm=manifest_map(now.get('tools/.installed-manifest.json',b''))
        known=set(manifest_map(before.get('tools/.installed-manifest.json',b'')))|set(newm)
        kit=lambda n:kit_owned(n,known)
        restore_list=sorted(n for n,b in before.items() if kit(n) and now.get(n)!=b)
        delete_list=sorted(n for n in now if n not in before and kit(n))
        # A kit file whose bytes are neither the backup's nor what the update installs may hold your edits: keep a copy.
        set_aside=sorted(n for n in restore_list+delete_list if n in now and n not in RUNTIME and not GENERATED.fullmatch(n) and digest(now[n])!=newm.get(n))
        mine_changed=sorted(n for n,b in before.items() if not kit(n) and now.get(n)!=b)
        others={n:digest(b) for n,b in now.items() if not kit(n)}
        print(f"Unfinished {info.get('operation','update')} {info.get('from_version')} to {info.get('to_version')}. Backup: {info.get('backup')}")
        print(f'Kit files to put back: {len(restore_list)} | new kit files to remove: {len(delete_list)} | your files changed since the backup (kept as they are now; the backup copy is saved beside each): {len(mine_changed)}')
        for n in restore_list:print('   put back:',n)
        for n in delete_list:print('   remove:',n)
        for n in set_aside:print('   copy kept first (not the kit version, may hold your edits):',n)
        for n in mine_changed:print('   yours, kept as now + backup copy saved beside it:',n)
        if not consent('Put the kit back from this backup?',args.yes):print('Cancelled; nothing changed');return
        ts=time.strftime('%Y%m%d-%H%M%S');saved=[]
        for n in set_aside:q=side_path(root,n,'yours',ts);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(now[n]);saved.append((n,q,now[n],'your copy of it'))
        for n in mine_changed:q=side_path(root,n,'recovered',ts);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(before[n]);saved.append((n,q,before[n],'backup copy'))
        for n in sorted(restore_list,key=lambda n:(n=='VERSION',n)):write_bytes_atomic(root/n,before[n],root)
        for n in delete_list:
            with contextlib.suppress(FileNotFoundError):(root/n).unlink()
        bad=[n for n in restore_list if not (root/n).is_file() or (root/n).read_bytes()!=before[n]]+[n for n in delete_list if (root/n).exists()]+[str(q) for n,q,b,w in saved if q.read_bytes()!=b]
        if bad:raise ValueError('Recover incomplete; these still differ: '+', '.join(bad[:10])+'. The backup is kept at '+str(info.get('backup')))
        changed_mine=check_others(root,others)
        if changed_mine:raise ValueError('Recover finished the kit files, but these of your files are not as they were just before recover: '+', '.join(changed_mine[:10])+'. The backup is kept at '+str(info.get('backup')))
        pp.unlink()
        print(f"Recovered: the kit is back to {info.get('from_version')} from {info.get('backup')}. Your other files ({len(others)}) were checked by hash after recover: unchanged.")
        for n,q,b,w in saved:print(f'   saved {w} beside {n}: {q.relative_to(root).as_posix()}')

def undo(root,args):
    statepath=root/'tools/.update-state'
    with update_lock(root):
        refuse_if_pending(root)
        if not statepath.exists():raise ValueError('No update to undo. Nothing changed.')
        st=read_json_small(statepath)
        if st.get('format')!=2 or not all(k in st for k in ('version','version_before','backup','backup_sha256','backup_files','changed')):raise ValueError('The update record has an unsupported format or is incomplete, so undo is refused. Nothing changed. Your backup zip is next to your mudmode folder.')
        if st.get('undone'):print('The last update was already undone. Nothing changed.');return
        cur=kit_version(root)
        if cur!=st['version']:raise ValueError(f"Your kit is at {cur}, but the last update was to {st['version']}, so undo is refused. Nothing changed. The kit may be mixed after an older unjournaled undo; backup: {st['backup']}. Keep it for manual kit-file restoration.")
        before=check_backup(root,st['backup'],st['backup_sha256'],st['backup_files'])
        if before.get('VERSION',b'').decode('utf8','replace').strip()!=st['version_before']:raise ValueError('The backup is not from the version before the update; refused. Nothing changed.')
        now=snapshot(root);selected=[];kept=[]
        owned=set(manifest_map(before.get('tools/.installed-manifest.json',b'')))|set(manifest_map(now.get('tools/.installed-manifest.json',b'')))
        for r in st['changed']:
            if r.get('generated_backup'):
                match=re.fullmatch(r'(.+)\.bak-[A-Za-z0-9-]+',r['path'])
                if not match:raise ValueError('Invalid generated backup')
                safe(match[1]);p=r['path']
            else:
                p=safe(r['path'])
                if protected(p):continue
            if not kit_owned(p,owned):continue
            h=digest(now[p]) if p in now else ''
            if h!=r['after']:kept.append(p);continue
            selected.append(p)
        for p in kept:print('   changed since the update, kept as it is now:',p)
        others={n:digest(b) for n,b in now.items() if n not in set(selected)}
        if not consent('Undo these kit changes?',args.yes):print('Cancelled; nothing changed');return
        # Roll back an interrupted undo to this exact pre-undo kit snapshot. Keep the original update backup too.
        ub=root.parent/('mudmode-backup-'+time.strftime('%Y%m%d-%H%M%S')+'-'+os.urandom(16).hex()+'.zip')
        writezip(ub,now)
        write_json_atomic(pending_path(root),dict(format=1,operation='undo',started=time.strftime('%Y-%m-%d %H:%M:%S %z'),pid=os.getpid(),from_version=cur,to_version=st['version_before'],backup=str(ub),backup_sha256=file_sha(ub),before={n:digest(v) for n,v in now.items()}))
        crash_hook('undo-journal')
        ts=time.strftime('%Y%m%d-%H%M%S');saved=[]
        for p in kept:
            if p in before and now.get(p)!=before[p]:q=side_path(root,p,'recovered',ts);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(before[p]);saved.append((p,q,before[p]))
        for i,n in enumerate(sorted(selected,key=lambda n:(n=='VERSION',n))):
            p=root/n
            if n=='VERSION':crash_hook('undo-before-version')
            if n in before:write_bytes_atomic(p,before[n],root)
            elif p.is_file():p.unlink()
            if i==0:crash_hook('undo-first-file')
            if i==len(selected)//2:crash_hook('undo-mid-files')
        crash_hook('undo-after-files')
        bad=[n for n in selected if (n in before and (not (root/n).is_file() or (root/n).read_bytes()!=before[n])) or (n not in before and (root/n).exists())]+[str(q) for p,q,b in saved if q.read_bytes()!=b]+check_others(root,others)
        if bad:raise ValueError('Undo incomplete; these files did not come back: '+', '.join(bad[:10])+'. The update record is unchanged; the backup is kept at '+str(st['backup']))
        st['undone']=True;write_json_atomic(statepath,st,root)
        crash_hook('undo-after-state')
        pending_path(root).unlink()
        print(f"Undo complete: the kit is back to {kit_version(root)} from {st['backup']}; replay high-water retained."+(' Kept your later edits: '+', '.join(kept)+'.' if kept else '')+f' Your other files ({len(others)}) were checked by hash after undo: unchanged.')
        for p,q,b in saved:print(f'   saved backup copy beside {p}: {q.relative_to(root).as_posix()}')
        backup_summary(root)

def consent(msg,yes=False):
    if yes:return True
    try:return input(msg+' [y/N] ')=='y'
    except EOFError:return False

def baseline(kit,root):
    full=(kit/'starter-kit/CORE.md').is_file();starter=kit/'starter-kit' if full else kit;out={}
    def add(src,path):
        if src.is_file() and not protected(path): b=src.read_bytes();out[path]=dict(path=path,sha256=digest(b),size=len(b))
    for d in ('templates','adapters','addons','modules','cores'):
        for p in (starter/d).rglob('*'):
            if p.is_file():add(p,d+'/'+p.relative_to(starter/d).as_posix())
    for n in ('CORE.md','RULE-MAP.md'):add(starter/n,n)
    for n in ('VERSION','WHAT-TO-SAY.md','CONTRIBUTING.md'):add(kit/n,n)
    for n in ('check-update.sh','check-update.ps1','update-key.pub'):add(kit/'setup'/n,'tools/'+n)
    for p in (kit/'tools').glob('*'):
        if re.fullmatch(r'(update|verify-minisign|record-install|update-common|mudmode|scrub_check)\.(ps1|sh|py)',p.name): add(p,'tools/'+p.name)
    if full:
        for n in ('MUDMODE.md','LICENSE.md','README-START-HERE.md'):add(kit/n,'full-kit/'+n)
        for d in ('adapters','tools','extras','FOR-CHAT-APPS'):
            for p in (kit/d).rglob('*'):
                if p.is_file():add(p,'full-kit/'+d+'/'+p.relative_to(kit/d).as_posix())
    write_json(root/'tools/.installed-manifest.json',dict(format=1,kit='full' if full else 'crew',version=(kit/'VERSION').read_text().strip(),files=sorted(out.values(),key=lambda r:r['path'])))

def verify(key,signature,data,work):
    lines=key.read_text().splitlines()
    if len(lines)!=2 or lines[1]!=PINNED or not re.fullmatch(r'untrusted comment: minisign public key [0-9A-F]{16}',lines[0]):raise ValueError('Pinned key mismatch')
    pk=base64.b64decode(lines[1],validate=True);ss=signature.decode().splitlines()
    if len(pk)!=42 or pk[:2]!=b'Ed' or len(ss)!=4 or not ss[2].startswith('trusted comment: '):raise ValueError('Invalid signature encoding')
    if not lines[0].endswith(' '+pk[2:10][::-1].hex().upper()):raise ValueError('Key header mismatch')
    sig=base64.b64decode(ss[1],validate=True);global_sig=base64.b64decode(ss[3],validate=True)
    if len(sig)!=74 or sig[:2]!=b'Ed' or sig[2:10]!=pk[2:10] or len(global_sig)!=64:raise ValueError('Unsupported signature/key')
    comment=ss[2][17:]
    if shutil.which('minisign'):
        (work/'verify-data').write_bytes(data);(work/'verify-sig').write_bytes(signature)
        subprocess.run(['minisign','-Vm',str(work/'verify-data'),'-x',str(work/'verify-sig'),'-P',PINNED],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    else:
        exe=shutil.which('openssl')
        if not exe or not subprocess.check_output([exe,'version']).startswith(b'OpenSSL 3.'):raise ValueError('Need minisign or OpenSSL 3; use manual update')
        # SubjectPublicKeyInfo Ed25519 OID 1.3.101.112.
        (work/'verify-key.der').write_bytes(bytes.fromhex('302a300506032b6570032100')+pk[10:])
        for i,(msg,sg) in enumerate(((data,sig[10:]),(sig[10:]+comment.encode(),global_sig))):
            (work/'verify-data').write_bytes(msg);(work/'verify-sig').write_bytes(sg)
            subprocess.run([exe,'pkeyutl','-verify','-pubin','-inkey',str(work/'verify-key.der'),'-keyform','DER','-rawin','-in',str(work/'verify-data'),'-sigfile',str(work/'verify-sig')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return comment

def version(s):
    if not isinstance(s,str) or not re.fullmatch(r'\d+\.\d+\.\d+',s):raise ValueError('Invalid version')
    return tuple(map(int,s.split('.')))
def unique_json(data):
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise ValueError('Duplicate JSON property')
            out[k]=v
        return out
    return json.loads(data,object_pairs_hook=pairs)

def update(args):
    root=P(args.root).absolute();tree_safe(root)
    if not (root/'CORE-LOCAL.md').is_file():raise ValueError('Not an installed mudmode folder')
    statepath=root/'tools/.update-state'
    if args.pack=='undo':args.undo=True
    if args.pack=='recover':args.recover=True
    if args.recover:return recover(root,args)
    if args.undo:return undo(root,args)
    if pending_path(root).exists():
        with update_lock(root):refuse_if_pending(root)
    if not args.pack and not args.url:
        with update_lock(root):pass
        print('No download. Full: download pack from Gumroad, then update.sh FILE. Crew: planned https://mudmodecrew.com/updates/crew/<ver>/pack.zip; hosting unproven. Pass --url explicitly.');return
    kind='full' if (root/'full-kit').is_dir() else 'crew'
    with stage_dir(root) as tmp:
        work=P(tmp);pack=P(args.pack) if args.pack else work/'pack.zip'
        if args.url:
            if kind=='full':raise ValueError('Full Kit only accepts local Gumroad packs')
            import urllib.request,urllib.parse
            u=urllib.parse.urlparse(args.url)
            if u.username or u.password or not (u.scheme=='https' or (os.environ.get('MUDMODE_TESTING')=='1' and u.scheme=='http' and u.hostname in ('127.0.0.1','localhost','::1'))):raise ValueError('HTTPS required')
            class NoRedirect(urllib.request.HTTPRedirectHandler):
                def redirect_request(self,*a,**kw):raise ValueError('Redirect refused')
            opener=urllib.request.build_opener(NoRedirect)
            with opener.open(urllib.request.Request(args.url,headers={'User-Agent':'mudmode-update'}),timeout=15) as r,pack.open('xb') as f:
                if r.status!=200:raise ValueError('HTTP error')
                count=0
                while True:
                    chunk=r.read(65536)
                    if not chunk:break
                    count+=len(chunk)
                    if count>MAX_PACK:raise ValueError('Pack too large')
                    f.write(chunk)
        if pack.stat().st_size>MAX_PACK:raise ValueError('Pack too large')
        with zipfile.ZipFile(pack) as z:
            entries={};total=0
            for e in z.infolist():
                safe(e.filename)
                if e.filename in ('tools/.update-state','tools/.installed-manifest.json'):raise ValueError('Runtime metadata in pack')
                if e.filename.lower() in entries or e.file_size>ENTRY_MAX or e.is_dir() or (e.external_attr>>16)&0o170000==0o120000:raise ValueError('Duplicate, linked or oversized entry')
                entries[e.filename.lower()]=e;total+=e.file_size
                if total>TOTAL_MAX:raise ValueError('Unpacked size limit')
            if z.getinfo('manifest.json').file_size>1024*1024 or z.getinfo('manifest.json.minisig').file_size>4096:raise ValueError('Manifest too large')
            data=read_entry(z,z.getinfo('manifest.json'),1024*1024);sigbytes=read_entry(z,z.getinfo('manifest.json.minisig'),4096)
            comment=verify(root/'tools/update-key.pub',sigbytes,data,work);m=unique_json(data)
            if m['format']!=1 or m['kit']!=kind or type(m['serial']) is not int or m['serial']<1:raise ValueError('Invalid schema/kit')
            if comment!=f"mudmode {kind} {m['version']} serial {m['serial']} sha256 {digest(data)}":raise ValueError('Trusted comment mismatch')
            current=version((root/'VERSION').read_text().strip())
            if version(m['version'])<=current or current<version(m['min_from']):raise ValueError('Older version/unsupported base')
            if statepath.exists() and m['serial']<=json.loads(statepath.read_text())['serial']:raise ValueError('Older serial refused')
            payload={};seen=set()
            for r in m['files']:
                n=safe(r['path'])
                if n.lower() in seen or n in ('manifest.json','manifest.json.minisig') or not re.fullmatch(r'[0-9a-f]{64}',r['sha256']) or type(r['size']) is not int or r['size']<0:raise ValueError('Invalid file record')
                seen.add(n.lower());b=read_entry(z,z.getinfo(n))
                if len(b)!=r['size'] or digest(b)!=r['sha256']:raise ValueError('Tampered pack file')
                payload[n]=b
            if len(entries)!=len(seen)+2:raise ValueError('Extra entry')
            if payload.get('VERSION',b'').decode().strip()!=m['version']:raise ValueError('Payload VERSION mismatch')
            if m['setup']!='setup/setup.ps1' or 'setup/setup.sh' not in payload:raise ValueError('Invalid setup')
        for n,b in payload.items():p=work/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
        with update_lock(root):
            refuse_if_pending(root);tree_safe(root);clean_stages(root,keep=work.name)
            cur=kit_version(root)
            if version(m['version'])<=version(cur):raise ValueError('Version changed while waiting for lock')
            if statepath.exists() and m['serial']<=json.loads(statepath.read_text())['serial']:raise ValueError('Serial changed while waiting for lock')
            cmd=['sh',str(work/'setup/setup.sh'),'--target',str(root),'--connect','none','--allow-dir','no','--local-only','--yes']
            subprocess.run(cmd+['--dry-run'],check=True)
            if not consent('Apply verified update?',args.yes):print('Cancelled; nothing changed');return
            before=snapshot(root);size=sum(map(len,before.values()))
            if shutil.disk_usage(root.parent).free<3*size+2*total+10*1024*1024:raise ValueError('Insufficient disk space')
            backup=root.parent/('mudmode-backup-'+time.strftime('%Y%m%d-%H%M%S')+'-'+os.urandom(8).hex()+'.zip');writezip(backup,before)
            hashes={n:digest(b) for n,b in before.items()};backup_sha=file_sha(backup)
            # Journal first: if this run is killed, the next run sees it and offers 'recover' from this backup.
            write_json_atomic(pending_path(root),dict(format=1,started=time.strftime('%Y-%m-%d %H:%M:%S %z'),pid=os.getpid(),from_version=cur,to_version=m['version'],serial=m['serial'],backup=str(backup),backup_sha256=backup_sha,before=hashes))
            try:
                crash_hook('before-setup')
                subprocess.run(cmd,check=True)
                crash_hook('after-setup')
                after=snapshot(root);known=set()
                if 'tools/.installed-manifest.json' in before:known.update(r['path'] for r in json.loads(before['tools/.installed-manifest.json'])['files'])
                known.update(r['path'] for r in json.loads((root/'tools/.installed-manifest.json').read_text())['files'])
                for n,b in before.items():
                    if (protected(n) or n not in known|{'SETUP-LOG.md','MODULES-ON.md','tools/.installed-manifest.json','tools/.update-state'}) and after.get(n)!=b:raise ValueError('User file changed; restoring')
                changed=[]
                for n,b in after.items():
                    mat=re.fullmatch(r'(.+)\.bak-[A-Za-z0-9-]+',n)
                    generated=bool(mat and n not in before and mat[1] in known and not protected(mat[1]))
                    if n!='tools/.update-state' and (not protected(n) or generated) and before.get(n)!=b:changed.append(dict(path=n,after=digest(b),generated_backup=generated))
                write_json_atomic(statepath,dict(format=2,serial=m['serial'],version=m['version'],version_before=cur,backup=str(backup),backup_sha256=backup_sha,backup_files=hashes,changed=changed,undone=False),root)
            except BaseException:
                restore(root,before)
                with contextlib.suppress(FileNotFoundError):pending_path(root).unlink()
                raise
            pending_path(root).unlink()
            print('Updated. Backup:',backup)
            backup_summary(root)

def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    for name in ('update',):
        p=sub.add_parser(name);p.add_argument('--root',default=str(P(__file__).absolute().parent.parent));p.add_argument('--yes',action='store_true')
        if name=='update':p.add_argument('pack',nargs='?',default='');p.add_argument('--url',default='');p.add_argument('--undo',action='store_true');p.add_argument('--recover',action='store_true')
    p=sub.add_parser('record-install');p.add_argument('--kit',required=True);p.add_argument('--root',required=True)
    a=ap.parse_args()
    try:
        if a.command=='record-install':baseline(P(a.kit),P(a.root))
        elif a.command=='update':update(a)
    except Exception as e:print(a.command+' stopped: '+str(e),file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())
