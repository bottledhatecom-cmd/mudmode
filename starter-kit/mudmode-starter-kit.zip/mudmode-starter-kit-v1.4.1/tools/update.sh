#!/bin/sh
# Python 3 required; no install/download of dependencies.
command -v python3 >/dev/null 2>&1 || { echo "Python 3 needed; use manual update. Nothing changed." >&2; exit 1; }
exec python3 "$(dirname "$0")/mudmode.py" update "$@"
