# Legacy minisign public-data verifier. Requires independent security review.
$script:MudPinnedKey = 'RWTSpU4Hr4bBpWocWhRC1lvgdmQkJ1mTFCSovtzIz0C6t281SJS3ej72'
Add-Type -AssemblyName System.Numerics
$BI = [System.Numerics.BigInteger]
$P = $BI::Pow(2,255) - 19
$Lq = $BI::Pow(2,252) + $BI::Parse("27742317777372353535851937790883648493")
function Invoke-MudModP($a){ $r = $a % $P; if ($r.Sign -lt 0) { $r += $P }; $r }
function Invoke-MudInv($a){ $BI::ModPow((Invoke-MudModP $a), $P - 2, $P) }
$D = Invoke-MudModP ((-121665) * (Invoke-MudInv 121666))
$SqrtM1 = $BI::ModPow(2, ($P - 1) / 4, $P)
function Invoke-MudLE($bytes){ $b = [byte[]]($bytes + [byte[]]@(0)); New-Object System.Numerics.BigInteger (,$b) }
function Invoke-MudPAdd($p1,$p2){
  $A = Invoke-MudModP (($p1[1]-$p1[0])*($p2[1]-$p2[0])); $B = Invoke-MudModP (($p1[1]+$p1[0])*($p2[1]+$p2[0]))
  $C = Invoke-MudModP (2*$p1[3]*$p2[3]*$D); $Dd = Invoke-MudModP (2*$p1[2]*$p2[2])
  $E=$B-$A; $F=$Dd-$C; $G=$Dd+$C; $H=$B+$A
  ,@((Invoke-MudModP ($E*$F)),(Invoke-MudModP ($G*$H)),(Invoke-MudModP ($F*$G)),(Invoke-MudModP ($E*$H)))
}
function Invoke-MudPMul([System.Numerics.BigInteger]$s,$pt){ $q = ,@($BI::Zero,$BI::One,$BI::One,$BI::Zero); $q=$q[0]
  while ($s.Sign -gt 0) { if (-not $s.IsEven) { $q = Invoke-MudPAdd $q $pt }; $pt = Invoke-MudPAdd $pt $pt; $s = $s / 2 }; ,$q }
function Invoke-MudPEq($a,$b){ ((Invoke-MudModP ($a[0]*$b[2] - $b[0]*$a[2])).IsZero) -and ((Invoke-MudModP ($a[1]*$b[2] - $b[1]*$a[2])).IsZero) }
function Invoke-MudDecomp($bytes){
  if ($bytes.Length -ne 32) { return $null }
  $b = [byte[]]$bytes.Clone(); $sign = ($b[31] -shr 7) -band 1; $b[31] = $b[31] -band 0x7F
  $y = Invoke-MudLE $b; if ($y -ge $P) { return $null }
  $x2 = Invoke-MudModP (($y*$y - 1) * (Invoke-MudInv ($D*$y*$y + 1)))
  if ($x2.IsZero) { if ($sign) { return $null }; return ,@($BI::Zero,$y,$BI::One,$BI::Zero) }
  $x = $BI::ModPow($x2, ($P + 3) / 8, $P)
  if (-not (Invoke-MudModP ($x*$x - $x2)).IsZero) { $x = Invoke-MudModP ($x * $SqrtM1) }
  if (-not (Invoke-MudModP ($x*$x - $x2)).IsZero) { return $null }
  if ([int]($x % 2) -ne $sign) { $x = $P - $x }
  ,@($x,$y,$BI::One,(Invoke-MudModP ($x*$y)))
}
$Gy = Invoke-MudModP (4 * (Invoke-MudInv 5)); $Gx2 = Invoke-MudModP (($Gy*$Gy - 1) * (Invoke-MudInv ($D*$Gy*$Gy + 1))); $Gx = $BI::ModPow($Gx2, ($P + 3) / 8, $P)
if (-not (Invoke-MudModP ($Gx*$Gx - $Gx2)).IsZero) { $Gx = Invoke-MudModP ($Gx * $SqrtM1) }; if (-not $Gx.IsEven) { $Gx = $P - $Gx }
$Gpt = @($Gx,$Gy,$BI::One,(Invoke-MudModP ($Gx*$Gy)))
function Invoke-MudEdVerify([byte[]]$pk,[byte[]]$msg,[byte[]]$sig){
  if ($sig.Length -ne 64) { return $false }
  $A = Invoke-MudDecomp $pk; if (-not $A) { return $false }
  $idpt = @($BI::Zero,$BI::One,$BI::One,$BI::Zero)
  if ((Invoke-MudPEq (Invoke-MudPMul 8 $A) $idpt) -or -not (Invoke-MudPEq (Invoke-MudPMul $Lq $A) $idpt)) { return $false }
  $Rb = [byte[]]$sig[0..31]; $R = Invoke-MudDecomp $Rb; if (-not $R) { return $false }
  if ((Invoke-MudPEq (Invoke-MudPMul 8 $R) $idpt) -or -not (Invoke-MudPEq (Invoke-MudPMul $Lq $R) $idpt)) { return $false }
  $s = Invoke-MudLE ([byte[]]$sig[32..63]); if ($s -ge $Lq) { return $false }
  $sha = [Security.Cryptography.SHA512]::Create(); try { $h = Invoke-MudLE ($sha.ComputeHash([byte[]]($Rb + $pk + $msg))) } finally { $sha.Dispose() }; $h = $h % $Lq
  Invoke-MudPEq (Invoke-MudPMul $s $Gpt) (Invoke-MudPAdd $R (Invoke-MudPMul $h $A))
}
function Invoke-MudMinisignVerify([string]$pubLine,[string[]]$sigLines,[byte[]]$data){
  $pkb = [Convert]::FromBase64String($pubLine); if ($pkb.Length -ne 42 -or $pkb[0] -ne 0x45 -or $pkb[1] -ne 0x64) { return "bad key" }
  if ($sigLines.Count -ne 4 -or -not $sigLines[2].StartsWith("trusted comment: ")) { return "bad sig file" }
  $sb = [Convert]::FromBase64String($sigLines[1]); if ($sb.Length -ne 74) { return "bad sig" }
  if (-not ($sb[0] -eq 0x45 -and $sb[1] -eq 0x64)) { return "not legacy Ed (prehashed ED needs BLAKE2b: unsupported; release signing MUST use minisign 0.12 -l)" }
  for ($i=2;$i -lt 10;$i++){ if ($sb[$i] -ne $pkb[$i]) { return "key id mismatch" } }
  $pk = [byte[]]$pkb[10..41]; $sig = [byte[]]$sb[10..73]
  if (-not (Invoke-MudEdVerify $pk $data $sig)) { return "FAIL signature" }
  $tc = [Text.Encoding]::UTF8.GetBytes($sigLines[2].Substring(17))
  if (-not (Invoke-MudEdVerify $pk ([byte[]]($sig + $tc)) ([Convert]::FromBase64String($sigLines[3])))) { return "FAIL trusted comment" }
  "OK: " + $sigLines[2].Substring(17)
}
