param([Parameter(Mandatory=$true)][string]$Kit,[Parameter(Mandatory=$true)][string]$Root)
. (Join-Path $PSScriptRoot 'update-common.ps1')
$map=@{}; $starter=$Kit; $kind='crew'
if(Test-Path (Join-Path $Kit 'starter-kit/CORE.md')) {$starter=Join-Path $Kit 'starter-kit';$kind='full'}
function Add-MudBaselineFile($Source,$Relative) {if(Test-Path -LiteralPath $Source -PathType Leaf) {$b=[IO.File]::ReadAllBytes($Source);$map[$Relative]=@{path=$Relative;sha256=(Get-MudHash $b);size=$b.Length}}}
foreach($dir in 'templates','adapters','addons','modules','cores') { $s=Join-Path $starter $dir; if(Test-Path $s) { foreach($f in Get-ChildItem $s -Recurse -File) {Add-MudBaselineFile $f.FullName ($dir+'/'+$f.FullName.Substring($s.Length+1).Replace('\','/'))} } }
foreach($f in 'CORE.md','RULE-MAP.md') {Add-MudBaselineFile (Join-Path $starter $f) $f}
foreach($f in 'VERSION','WHAT-TO-SAY.md','CONTRIBUTING.md') {Add-MudBaselineFile (Join-Path $Kit $f) $f}
foreach($f in Get-ChildItem (Join-Path $Kit 'setup') -File) {if($f.Name -match '^(check-update\.(ps1|sh)|update-key.pub)$') {Add-MudBaselineFile $f.FullName ('tools/'+$f.Name)}}
foreach($f in Get-ChildItem (Join-Path $Kit 'tools') -File) {if($f.Name -eq 'submit-route.txt' -or $f.Name -match '^(update|submit|verify-minisign|record-install|update-common|mudmode|scrub_check)\.(ps1|sh|py)$') {Add-MudBaselineFile $f.FullName ('tools/'+$f.Name)}}
if($kind -eq 'full') {
 foreach($f in 'MUDMODE.md','LICENSE.md','README-START-HERE.md') {Add-MudBaselineFile (Join-Path $Kit $f) ('full-kit/'+$f)}
 foreach($dir in 'adapters','tools','extras','FOR-CHAT-APPS') { $s=Join-Path $Kit $dir; if(Test-Path $s) {foreach($f in Get-ChildItem $s -Recurse -File) {Add-MudBaselineFile $f.FullName ('full-kit/'+$dir+'/'+$f.FullName.Substring($s.Length+1).Replace('\','/'))}} }
}
$files=@($map.Values | Where-Object {-not (Test-MudProtected $_.path)} | Sort-Object path)
Write-MudText (Join-Path $Root 'tools/.installed-manifest.json') (@{format=1;kit=$kind;version=([IO.File]::ReadAllText((Join-Path $Kit 'VERSION')).Trim());files=$files}|ConvertTo-Json -Depth 8)
