#!/usr/bin/env python3
"""Privacy scrub check for anything that may become public (mudmode v1.4.1).
Usage: python3 scrub_check.py [--strict] <folder-or-file> ...
Exit 1 if any hit. Prints only file:line:kind and, for a pattern hit, a masked preview (first 2 characters
and the length). It never prints a deny word or a full matched value, so running it inside an AI chat
doesn't copy your secrets or private words into the chat. Also lists capitalized words for a human read.
- Deny terms (your private words, from deny-list.private.txt next to this script) match whole words.
- Files that must never be shared (other deny lists, *.private.* files, *.bak-* backups) are flagged
  MUST-NOT-SHIP and counted as hits. Only this script's own deny list is skipped, and only by its real path.
- Copyright lines: a deny word on a copyright, trademark or licensor line of a LICENSE or README file is
  listed as "allowed-copyright-line" and not counted (an owner who publishes under their own name puts it
  there on purpose). Only these lines count as such: a line that starts with "©", "(c)" or "Copyright";
  a line with "© <year>"; a line that starts with "Licensor"; "The Licensor, <name>, grants you this
  license"; "This kit is licensed to you, one person, by <name> under the mudmode ... License"; and a line
  that starts with '"mudmode" is a trademark of'. Add --strict to count those too.
- Web links: only the host (and port) is printed, never a user name or password in the link (a link with
  one is counted as a hit) and never anything after the host (a ?query or #part), and any part of the host
  that is a deny word is masked. A key-like value after ? or # (token=, secret=, key=, sig=, code= ...)
  is counted as "url-secret" with a masked preview, with or without a path.
- Text formats: files are read as UTF-8 (with or without a BOM) or as UTF-16 or UTF-32 with a BOM, which
  covers what Windows PowerShell 5.1 writes. A file it can't read as text (another format, or one with NUL
  bytes) is listed as "not-text" and counted as a hit: it is never passed. The deny list is read the same
  way; a deny list it can't read stops the scan (exit 2), and an empty one prints a warning.
- The capitalized-word list never shows a deny word or a full pattern-matched credential; sensitive tokens are masked.
- --core-local PATH also treats the owner name in that CORE-LOCAL.md and this computer's
  user name as deny words (never printed). Street-address-like text counts as a hit. Words about family,
  school or health are listed as "review-personal" for a human read (not counted).
- This is a pattern scan, not a privacy guarantee: it can miss personal details. A person must read every file."""
import re, sys, os, collections
HERE=os.path.dirname(os.path.abspath(__file__))
DENY=os.path.join(HERE,'deny-list.private.txt')
argv=sys.argv[1:]; CORE_LOCAL=None
if '--core-local' in argv:
    i=argv.index('--core-local'); CORE_LOCAL=argv[i+1] if i+1<len(argv) else ''; del argv[i:i+2]
args=[a for a in argv if a!='--strict']; STRICT='--strict' in argv
if not args:
    print('Usage: python3 scrub_check.py [--strict] <folder-or-file> ...  (checks what you are about to share)'); sys.exit(2)
if not os.path.exists(DENY):
    print('scrub_check: your private deny list is missing.')
    print('Make a plain text file named deny-list.private.txt next to this script (in the tools folder),')
    print('with your own private words, one per line: your name, family names, emails, street, user name, project names.')
    print('Lines starting with # are notes. Never share that file. Then run this check again.')
    sys.exit(2)
BOMS=((b'\x00\x00\xfe\xff','utf-32-be'),(b'\xff\xfe\x00\x00','utf-32-le'),(b'\xef\xbb\xbf','utf-8'),(b'\xfe\xff','utf-16-be'),(b'\xff\xfe','utf-16-le'))
def split_lines(text):
    # like Python text mode: \r\n, \r and \n end a line; no empty line after a final line end
    if not text: return []
    parts=re.split(r'\r\n|\r|\n',text)
    if text.endswith(('\n','\r')): parts=parts[:-1]
    return parts
def read_lines(path):
    # UTF-8 (BOM or not), or UTF-16/UTF-32 with a BOM; None = not text this scan can read (never passed)
    data=open(path,'rb').read(); enc='utf-8'
    for bom,e in BOMS:
        if data.startswith(bom): data=data[len(bom):]; enc=e; break
    try: text=data.decode(enc)
    except UnicodeDecodeError: return None
    if '\x00' in text: return None
    return split_lines(text)
DENY_REAL=os.path.realpath(DENY)
try: deny_lines=read_lines(DENY)
except OSError: deny_lines=None
if deny_lines is None:
    print("scrub_check: your private deny list cannot be read as text. scan stopped.")
    print('Check access to deny-list.private.txt, save it as UTF-8 text with one private word per line, then run this check again.')
    sys.exit(2)
deny=[l.strip().lower() for l in deny_lines if l.strip() and not l.startswith('#')]
if not deny: print('WARNING: your private deny list is empty. scan continues without its checks, not a safety guarantee. add words to deny-list.private.txt and rescan.')
EXTRA=[]   # (word, why) from CORE-LOCAL.md and this computer; never printed
NOT_NAMES={'the','owner','kept','name','mud','you','me','user','admin','root','home','users','box'}
def add_extra(word,why):
    w=word.strip().lower()
    if len(w)>=3 and w not in NOT_NAMES and re.fullmatch(r"[a-z0-9][a-z0-9._'-]*",w): EXTRA.append((w,why))
if CORE_LOCAL is not None:
    try:
        cl=read_lines(CORE_LOCAL)
        if cl is None: cl=split_lines(open(CORE_LOCAL,'rb').read().decode('utf-8','replace'))
        for line in cl:
            m=re.match(r'\s*-\s*\*\*Owner[^*]*\*\*\s*(.+)$',line)
            if m:
                for part in re.findall(r"[A-Za-z][A-Za-z'-]+",m.group(1)): add_extra(part,'owner name in CORE-LOCAL.md')
    except OSError: pass
    try:
        import getpass; add_extra(getpass.getuser(),'this computer\'s user name')
    except Exception: pass
    add_extra(os.path.basename(os.path.expanduser('~').rstrip('/\\')),'your home folder name')
PAT={
 'email':r'[\w.+-]+@[\w-]+\.[\w.]+',
 'uuid':r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b',
 'hex-id':r'\b[0-9a-f]{12,}\b',
 'phone':r'(?<!\d)(\+?1[ .-]?)?\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4}(?!\d)',
 'ip':r'\b\d{1,3}(\.\d{1,3}){3}\b',
 'win-path':r'[A-Za-z]:\\\\?[\w]',
 'home-path':r'/(home|Users)/\w+',
 'money':r'\$\s?\d',
 'secret-word':r'(?i)\b(api[_-]?key|token|password|passwd|secret)\s*[:=]\s*\S+',
 'bearer-token':r'(?i)\bbearer\s+[A-Za-z0-9._~+/-]{12,}=*',
 'sk-key':r'\bsk-(?:proj-|ant-|live_|test_)?[A-Za-z0-9_-]{16,}',
 'xai-key':r'\bxai-[A-Za-z0-9_-]{16,}',
 'github-token':r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})',
 'aws-key':r'\b(?:AKIA|ASIA)[0-9A-Z]{16}\b',
 'google-key':r'\bAIza[0-9A-Za-z_-]{30,}',
 'slack-token':r'\bxox[abposr]-[A-Za-z0-9-]{10,}',
 'private-key':r'-----BEGIN [A-Z ]*PRIVATE KEY-----',
 'jwt':r'\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}',
 'package-id':r'\b(com|app|io)\.[a-z0-9]+\.[a-z0-9.]+\b',
 'street-address':r'(?i)\b\d{1,6}\s+(?:[a-z][a-z]+\s+){1,3}(?:st|street|ave|avenue|rd|road|blvd|boulevard|ln|lane|dr|drive|ct|court|terrace|circle|hwy|highway|pkwy|parkway)\b',
 'po-box':r'(?i)\bp\.?\s?o\.?\s+box\s+\d+',
 'user-path':r'(?i)\b(?:users|home|documents and settings)[\\/][a-z0-9._-]{2,}',
 'url-secret':r'(?i)[?&#][A-Za-z0-9_.-]*(?:token|secret|key|sig|password|passwd|pwd|auth|code|credential)[A-Za-z0-9_.-]*=[^&#\s"\'<>]+',
}
PERSONAL=r'(?i)\b(?:my|our|his|her|their)\s+(?:son|daughter|kids?|child(?:ren)?|wife|husband|partner|mom|dad|mother|father|brother|sister|grand\w+)\b|\b\w+\s+(?:elementary|middle|high)\s+school\b|\b(?:diagnos\w*|autis\w*|adhd|diabet\w*|cancer|pregnan\w*|therap(?:y|ist)|medication|prescription|disabilit\w*|seizures?|asthma|allerg\w*)\b'
URL=r'https?://[^\s/)>\]"\']+'
HOST=re.compile(r'(?:[A-Za-z0-9._~-]|[^\x00-\x7f])*(?::[0-9]+)?')
COPY_LINE=re.compile(r'(?i)^\s*(?:©|\(c\)|copyright\b|licensor\b|"mudmode" is a trademark of\b)'
  r'|©\s*(?:19|20)\d\d\b'
  r'|\bThe Licensor, [^,]{1,80}, grants you this license\b'
  r'|^\s*This kit is licensed to you, one person, by [^.]{1,80}? under the mudmode [A-Za-z ]{0,40}License\b')
ALLOW_CAPS=set('''CORE AI AIs OK OKs PASS WARN FAIL USED UP SUPERSEDED README AGENTS HANDOFF LESSONS PROGRESS JOBS LEDGER DECISIONS
OPEN QUESTIONS CHECKLIST SCRUB ADDON LOCAL PROJECT YYYY MM DD HHMM AM PM CST CDT PR Markdown Android Recipe Box Area Owner Rule Words Who Never Money How Version
Example Worked Format Detail Enforced When Read Write Register Ask Back Update Rewrite End Keep Make Copy Edit Start Grow Week Later Sharing License Provided Not
Quick What Tool Where Guard Memory Scheduler Before While At No Can Can't Off Another Shared Nothing Follow Quality Order Review Every Tell Save Real Reports
Leave Handoffs This Orders One Always Lessons Next Written Goal Stage Live Decisions Open Running Risks Step Last Blockers Outputs Name Status Status Add Test Extra
Store If It You Your The A An And Or For In On Of To Be Run Check Fix Use Get Put Note Mark Cap Merge Move Replace Say Report Done Draft Release Starter Kit
Everyday Pro Part SAFEGUARDS RULES'''.split())
DENYSET=set(deny); DENYTOK={t for d in deny for t in re.findall(r'[a-z0-9]+',d)}; hits=0; allowed=0; caps=collections.Counter()
def mask(s): return (s[:2]+'…' if len(s)>2 else '…')+f'({len(s)} chars)'
def safe_url(u):
    # scheme://[user[:password]@]host[:port] -> (host with deny words masked, had_login)
    # only the part before any ?query or #part is looked at, and only its host[:port] run is ever printed
    scheme,rest=u.split('://',1); auth=re.match(r'[^?#]*',rest).group(0)
    login='@' in rest; host=HOST.match(auth.rsplit('@',1)[-1]).group(0)   # a login anywhere in the link counts
    for i,d in enumerate(deny,1):
        host=re.sub(r'(?i)(?<![a-z0-9])'+re.escape(d)+r'(?![a-z0-9])',f'[deny word #{i}]',host)
    if any(re.search(r,host if kind!='hex-id' else host.lower()) for kind,r in PAT.items()): host=mask(host)
    return scheme+'://'+host[:60], login
def must_not_ship(name):
    low=name.lower()
    return low.startswith('deny-list') or '.private.' in low or low.endswith('.private') or '.bak-' in low
def scan(p):
    global hits, allowed
    if os.path.realpath(p)==DENY_REAL: return   # this script's own deny list (by real path only)
    name=os.path.basename(p)
    if must_not_ship(name):
        print(f'{p}:0:MUST-NOT-SHIP (a deny list, private file or backup; take it out before you share)'); hits+=1
        if name.lower().startswith('deny-list'): return   # its lines are private words: never print or rescan them
    legal=re.match(r'(?i)(license|licence|readme)',name) is not None
    try: lines=read_lines(p)
    except OSError as e: print(f'{p}:0:could-not-read ({e.__class__.__name__})'); hits+=1; return
    if lines is None:
        print(f"{p}:0:not-text (not scanned as text; counted as a hit; save a text copy as UTF-8 and rescan, or exclude this file from sharing)"); hits+=1; return
    for n,line in enumerate(lines,1):
        low=line.lower()
        for i,d in enumerate(deny,1):
            if re.search(r'(?<![a-z0-9])'+re.escape(d)+r'(?![a-z0-9])',low):
                if legal and not STRICT and COPY_LINE.search(line):
                    print(f'{p}:{n}:allowed-copyright-line (deny word #{i}; not counted; --strict counts it)'); allowed+=1
                else:
                    print(f'{p}:{n}:deny (word #{i} in your deny list)'); hits+=1
        for w,why in EXTRA:
            if re.search(r'(?<![a-z0-9])'+re.escape(w)+r'(?![a-z0-9])',low): print(f'{p}:{n}:personal ({why}; not printed)'); hits+=1
        for m in re.finditer(PERSONAL,line): print(f'{p}:{n}:review-personal:{mask(m.group(0))} (family, school or health words: read this line yourself)')
        sensitive=[]
        for k,r in PAT.items():
            for m in re.finditer(r,line if k!='hex-id' else low):
                sensitive.append(m.span())
                print(f'{p}:{n}:{k}:{mask(m.group(0))}'); hits+=1
        for m in re.finditer(URL,line):
            host,login=safe_url(m.group(0))
            if login: print(f'{p}:{n}:url-login (a user name or password in a link; not printed)'); hits+=1
            print(f'{p}:{n}:review-url:{host} (host only)')
        for cm in re.finditer(r"\b[A-Z][a-zA-Z']+\b",line):
            w=cm.group(0)
            wl=w.lower(); base=wl[:-2] if wl.endswith("'s") else wl
            if w not in ALLOW_CAPS and wl not in DENYSET and base not in DENYTOK and wl not in DENYTOK and wl not in {e for e,_ in EXTRA}:
                risky=any(ch.isdigit() for ch in w) or any(re.search(r,w if kind!='hex-id' else w.lower()) for kind,r in PAT.items()) or any(cm.start()<end and cm.end()>start for start,end in sensitive)
                caps[mask(w) if risky else w]+=1   # no full matched credential in the human-read list
for a in args:
    if os.path.isdir(a):
        for r,ds,fs in os.walk(a):
            ds.sort()
            for f in sorted(fs): scan(os.path.join(r,f))
    elif os.path.exists(a): scan(a)
    else: print(f'{a}:0:not-found'); hits+=1
print('CAPITALIZED WORDS FOR HUMAN READ:',', '.join(f'{w}({c})' for w,c in sorted(caps.items())))
print('ALLOWED COPYRIGHT LINES:',allowed)
print('HITS:',hits)
print('This scan can miss personal details. Read every file yourself before you share it.')
sys.exit(1 if hits else 0)
