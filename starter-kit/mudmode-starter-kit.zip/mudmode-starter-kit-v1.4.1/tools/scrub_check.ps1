# Privacy scrub check for anything that may become public (mudmode v1.4.1), PowerShell edition.
# A line-for-line port of tools/scrub_check.py so Windows needs no Python: same patterns, same order,
# same output and exit codes (0 clean, 1 hits, 2 usage or missing deny list). Runs on Windows PowerShell 5.1
# and PowerShell 7. This file is pure ASCII on purpose (PS 5.1 reads a BOM-less script as ANSI).
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File scrub_check.ps1 [--strict] [--core-local PATH] <folder-or-file> ...
# It never prints a deny word or a full matched value: only file:line:kind and, for a pattern hit, a masked
# preview (first 2 characters and the length). Local only: no network code. See scrub_check.py for the full notes.
# Files are read as UTF-8 (BOM or not) or UTF-16/UTF-32 with a BOM; a file it can't read as text is "not-text" and
# counted, never passed. A deny list it can't read stops the scan (exit 2); an empty one prints a warning.
# Links: only host[:port] is printed, never a login or anything after the host (?query, #part); a key-like
# value after ? or # (token=, secret=, key=, sig=, code= ...) is counted as url-secret.
# This is a pattern scan, not a privacy guarantee: it can miss personal details. A person must read every file.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$ELL = [string][char]0x2026          # the ellipsis the Python scan prints
$COPY = [string][char]0x00A9         # the copyright sign
$utf8 = New-Object System.Text.UTF8Encoding($false, $false)   # invalid bytes become U+FFFD, like errors='replace'
# the buyer's console encoding and folder are put back when the scan ends (Finish)
$script:oldEnc = $null; try { $script:oldEnc = [Console]::OutputEncoding; [Console]::OutputEncoding = $utf8 } catch { }
# .NET resolves relative paths against the process folder; make that PowerShell's own location, like Python's cwd
$script:oldCwd = [Environment]::CurrentDirectory
try { [Environment]::CurrentDirectory = (Get-Location -PSProvider FileSystem).ProviderPath } catch { }
function Finish([int]$code) {
    try { [Environment]::CurrentDirectory = $script:oldCwd } catch { }
    if ($null -ne $script:oldEnc) { try { [Console]::OutputEncoding = $script:oldEnc } catch { } }
    exit $code
}

$HERE = Split-Path -Parent $MyInvocation.MyCommand.Path
$DENYFILE = Join-Path $HERE 'deny-list.private.txt'
$argv = New-Object System.Collections.Generic.List[string]
foreach ($a in $args) { $argv.Add([string]$a) }
$CORE_LOCAL = $null
$ci = $argv.IndexOf('--core-local')
if ($ci -ge 0) {
    if ($ci + 1 -lt $argv.Count) { $CORE_LOCAL = $argv[$ci + 1]; $argv.RemoveRange($ci, 2) } else { $CORE_LOCAL = ''; $argv.RemoveAt($ci) }
}
$STRICT = $argv.Contains('--strict')
$targets = @($argv | Where-Object { $_ -cne '--strict' })
if ($targets.Count -eq 0) {
    Write-Output 'Usage: scrub_check.ps1 [--strict] <folder-or-file> ...  (checks what you are about to share)'; Finish 2
}
if (-not (Test-Path -LiteralPath $DENYFILE -PathType Leaf)) {
    Write-Output 'scrub_check: your private deny list is missing.'
    Write-Output 'Make a plain text file named deny-list.private.txt next to this script (in the tools folder),'
    Write-Output 'with your own private words, one per line: your name, family names, emails, street, user name, project names.'
    Write-Output 'Lines starting with # are notes. Never share that file. Then run this check again.'
    Finish 2
}

function Split-Lines([string]$text) {
    # like Python text mode: \r\n, \r and \n end a line; no empty line after a final line end
    if ($text.Length -eq 0) { return ,@() }
    $parts = [regex]::Split($text, "\r\n|\r|\n")
    if ($text.EndsWith("`n", [StringComparison]::Ordinal) -or $text.EndsWith("`r", [StringComparison]::Ordinal)) { $parts = $parts[0..($parts.Count - 2)] }
    return ,@($parts)
}
function Read-TextLines([string]$path) {
    # UTF-8 (BOM or not), or UTF-16/UTF-32 with a BOM, decoded strictly; $null = not text this scan can read (never passed)
    $b = [IO.File]::ReadAllBytes($path)
    $enc = New-Object System.Text.UTF8Encoding($false, $true); $skip = 0
    if ($b.Length -ge 4 -and $b[0] -eq 0 -and $b[1] -eq 0 -and $b[2] -eq 0xFE -and $b[3] -eq 0xFF) { $enc = New-Object System.Text.UTF32Encoding($true, $false, $true); $skip = 4 }
    elseif ($b.Length -ge 4 -and $b[0] -eq 0xFF -and $b[1] -eq 0xFE -and $b[2] -eq 0 -and $b[3] -eq 0) { $enc = New-Object System.Text.UTF32Encoding($false, $false, $true); $skip = 4 }
    elseif ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) { $skip = 3 }
    elseif ($b.Length -ge 2 -and $b[0] -eq 0xFE -and $b[1] -eq 0xFF) { $enc = New-Object System.Text.UnicodeEncoding($true, $false, $true); $skip = 2 }
    elseif ($b.Length -ge 2 -and $b[0] -eq 0xFF -and $b[1] -eq 0xFE) { $enc = New-Object System.Text.UnicodeEncoding($false, $false, $true); $skip = 2 }
    try { $text = $enc.GetString($b, $skip, $b.Length - $skip) } catch { return $null }
    if ($text.IndexOf([char]0) -ge 0) { return $null }
    return ,(Split-Lines $text)
}
function Get-RealPath([string]$p) {
    $full = [IO.Path]::GetFullPath($p)
    try {
        $item = Get-Item -LiteralPath $full -Force -ErrorAction Stop
        if ($item.PSObject.Properties['Target'] -and $item.Target) { $t = @($item.Target)[0]; if ($t) { return [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $full) $t)) } }
    } catch { }
    return $full
}
function Esc([string]$s) { return [regex]::Escape($s) }
function Count-Chars([string]$s) { $n = 0; foreach ($ch in $s.ToCharArray()) { if (-not [char]::IsLowSurrogate($ch)) { $n++ } }; return $n }
function Mask([string]$s) {
    $n = Count-Chars $s
    if ($n -gt 2) { $k = 2; if ([char]::IsHighSurrogate($s[0])) { $k++ }; if ($s.Length -gt $k - 1 -and [char]::IsHighSurrogate($s[$k - 1])) { $k++ }; $head = $s.Substring(0, [Math]::Min($k, $s.Length)) + $ELL } else { $head = $ELL }
    return "$head($n chars)"
}

$DENY_REAL = Get-RealPath $DENYFILE
$deny = New-Object System.Collections.Generic.List[string]
$denyLines = $null; try { $denyLines = Read-TextLines $DENYFILE } catch { $denyLines = $null }
if ($null -eq $denyLines) {
    Write-Output "scrub_check: your private deny list cannot be read as text. scan stopped."
    Write-Output 'Check access to deny-list.private.txt, save it as UTF-8 text with one private word per line, then run this check again.'
    Finish 2
}
foreach ($l in $denyLines) { if ($l.Trim().Length -gt 0 -and -not $l.StartsWith('#', [StringComparison]::Ordinal)) { $deny.Add($l.Trim().ToLowerInvariant()) } }
if ($deny.Count -eq 0) { Write-Output 'WARNING: your private deny list is empty. scan continues without its checks, not a safety guarantee. add words to deny-list.private.txt and rescan.' }
$EXTRA = New-Object System.Collections.Generic.List[object]   # (word, why) from CORE-LOCAL.md and this computer; never printed
$NOT_NAMES = @('the','owner','kept','name','mud','you','me','user','admin','root','home','users','box')
function Add-Extra([string]$word, [string]$why) {
    $w = $word.Trim().ToLowerInvariant()
    if ($w.Length -ge 3 -and ($NOT_NAMES -notcontains $w) -and [regex]::IsMatch($w, "^[a-z0-9][a-z0-9._'-]*\z")) { $EXTRA.Add(@($w, $why)) }
}
if ($null -ne $CORE_LOCAL) {
    try {
        if ($CORE_LOCAL -and (Test-Path -LiteralPath $CORE_LOCAL -PathType Leaf)) {
            $cl = Read-TextLines $CORE_LOCAL
            if ($null -eq $cl) { $cl = Split-Lines ($utf8.GetString([IO.File]::ReadAllBytes($CORE_LOCAL))) }
            foreach ($line in $cl) {
                $m = [regex]::Match($line, '^\s*-\s*\*\*Owner[^*]*\*\*\s*(.+)$')
                if ($m.Success) { foreach ($part in [regex]::Matches($m.Groups[1].Value, "[A-Za-z][A-Za-z'-]+")) { Add-Extra $part.Value 'owner name in CORE-LOCAL.md' } }
            }
        }
    } catch { }
    # same order as Python's getpass.getuser(): LOGNAME, USER, LNAME, USERNAME
    $u = $null; foreach ($v in 'LOGNAME','USER','LNAME','USERNAME') { $x = [Environment]::GetEnvironmentVariable($v); if ($x) { $u = $x; break } }
    if ($u) { Add-Extra $u "this computer's user name" }
    $homeDir = $env:USERPROFILE; if (-not $homeDir) { $homeDir = $HOME }
    if ($homeDir) { Add-Extra (Split-Path -Leaf ($homeDir.TrimEnd('/','\'))) 'your home folder name' }
}

# Same names, same order, same patterns as scrub_check.py (an ordered list, like the Python dict)
$PAT = @(
 @('email', '[\w.+-]+@[\w-]+\.[\w.]+'),
 @('uuid', '\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b'),
 @('hex-id', '\b[0-9a-f]{12,}\b'),
 @('phone', '(?<!\d)(\+?1[ .-]?)?\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4}(?!\d)'),
 @('ip', '\b\d{1,3}(\.\d{1,3}){3}\b'),
 @('win-path', '[A-Za-z]:\\\\?[\w]'),
 @('home-path', '/(home|Users)/\w+'),
 @('money', '\$\s?\d'),
 @('secret-word', '(?i)\b(api[_-]?key|token|password|passwd|secret)\s*[:=]\s*\S+'),
 @('bearer-token', '(?i)\bbearer\s+[A-Za-z0-9._~+/-]{12,}=*'),
 @('sk-key', '\bsk-(?:proj-|ant-|live_|test_)?[A-Za-z0-9_-]{16,}'),
 @('xai-key', '\bxai-[A-Za-z0-9_-]{16,}'),
 @('github-token', '\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})'),
 @('aws-key', '\b(?:AKIA|ASIA)[0-9A-Z]{16}\b'),
 @('google-key', '\bAIza[0-9A-Za-z_-]{30,}'),
 @('slack-token', '\bxox[abposr]-[A-Za-z0-9-]{10,}'),
 @('private-key', '-----BEGIN [A-Z ]*PRIVATE KEY-----'),
 @('jwt', '\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}'),
 @('package-id', '\b(com|app|io)\.[a-z0-9]+\.[a-z0-9.]+\b'),
 @('street-address', '(?i)\b\d{1,6}\s+(?:[a-z][a-z]+\s+){1,3}(?:st|street|ave|avenue|rd|road|blvd|boulevard|ln|lane|dr|drive|ct|court|terrace|circle|hwy|highway|pkwy|parkway)\b'),
 @('po-box', '(?i)\bp\.?\s?o\.?\s+box\s+\d+'),
 @('user-path', '(?i)\b(?:users|home|documents and settings)[\\/][a-z0-9._-]{2,}'),
 @('url-secret', '(?i)[?&#][A-Za-z0-9_.-]*(?:token|secret|key|sig|password|passwd|pwd|auth|code|credential)[A-Za-z0-9_.-]*=[^&#\s"''<>]+')
)
$PATRX = @(); foreach ($p in $PAT) { $PATRX += ,@($p[0], (New-Object regex($p[1]))) }
$PERSONAL = New-Object regex('(?i)\b(?:my|our|his|her|their)\s+(?:son|daughter|kids?|child(?:ren)?|wife|husband|partner|mom|dad|mother|father|brother|sister|grand\w+)\b|\b\w+\s+(?:elementary|middle|high)\s+school\b|\b(?:diagnos\w*|autis\w*|adhd|diabet\w*|cancer|pregnan\w*|therap(?:y|ist)|medication|prescription|disabilit\w*|seizures?|asthma|allerg\w*)\b')
$URL = New-Object regex('https?://[^\s/)>\]"'']+')
$AUTHRX = New-Object regex('\A[^?#]*')
$HOSTRX = New-Object regex('\A(?:[A-Za-z0-9._~-]|[^\x00-\x7f])*(?::[0-9]+)?')
$COPY_LINE = New-Object regex(('(?i)^\s*(?:' + $COPY + '|\(c\)|copyright\b|licensor\b|"mudmode" is a trademark of\b)' +
  '|' + $COPY + '\s*(?:19|20)\d\d\b' +
  '|\bThe Licensor, [^,]{1,80}, grants you this license\b' +
  '|^\s*This kit is licensed to you, one person, by [^.]{1,80}? under the mudmode [A-Za-z ]{0,40}License\b'))
$CAPSRX = New-Object regex("\b[A-Z][a-zA-Z']+\b")
$ALLOW_CAPS = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
foreach ($w in (@'
CORE AI AIs OK OKs PASS WARN FAIL USED UP SUPERSEDED README AGENTS HANDOFF LESSONS PROGRESS JOBS LEDGER DECISIONS
OPEN QUESTIONS CHECKLIST SCRUB ADDON LOCAL PROJECT YYYY MM DD HHMM AM PM CST CDT PR Markdown Android Recipe Box Area Owner Rule Words Who Never Money How Version
Example Worked Format Detail Enforced When Read Write Register Ask Back Update Rewrite End Keep Make Copy Edit Start Grow Week Later Sharing License Provided Not
Quick What Tool Where Guard Memory Scheduler Before While At No Can Can't Off Another Shared Nothing Follow Quality Order Review Every Tell Save Real Reports
Leave Handoffs This Orders One Always Lessons Next Written Goal Stage Live Decisions Open Running Risks Step Last Blockers Outputs Name Status Status Add Test Extra
Store If It You Your The A An And Or For In On Of To Be Run Check Fix Use Get Put Note Mark Cap Merge Move Replace Say Report Done Draft Release Starter Kit
Everyday Pro Part SAFEGUARDS RULES
'@ -split '\s+')) { if ($w) { [void]$ALLOW_CAPS.Add($w) } }
$DENYSET = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
$DENYTOK = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
foreach ($d in $deny) { [void]$DENYSET.Add($d); foreach ($t in [regex]::Matches($d, '[a-z0-9]+')) { [void]$DENYTOK.Add($t.Value) } }
$EXTRASET = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
foreach ($e in $EXTRA) { [void]$EXTRASET.Add($e[0]) }
$DENYRX = @(); foreach ($d in $deny) { $DENYRX += ,(New-Object regex('(?<![a-z0-9])' + (Esc $d) + '(?![a-z0-9])')) }
$DENYRXI = @(); foreach ($d in $deny) { $DENYRXI += ,(New-Object regex('(?i)(?<![a-z0-9])' + (Esc $d) + '(?![a-z0-9])')) }
$EXTRARX = @(); foreach ($e in $EXTRA) { $EXTRARX += ,@((New-Object regex('(?<![a-z0-9])' + (Esc $e[0]) + '(?![a-z0-9])')), $e[1]) }
$script:hits = 0; $script:allowed = 0
$caps = New-Object 'System.Collections.Generic.Dictionary[string,int]' ([StringComparer]::Ordinal)

function Safe-Url([string]$u) {
    # scheme://[user[:password]@]host[:port] -> (host with deny words masked, had_login)
    # only the part before any ?query or #part is looked at, and only its host[:port] run is ever printed
    $i = $u.IndexOf('://', [StringComparison]::Ordinal); $scheme = $u.Substring(0, $i); $rest = $u.Substring($i + 3)
    $auth = $AUTHRX.Match($rest).Value
    $login = $rest.Contains('@'); $hostPart = $HOSTRX.Match($auth.Substring($auth.LastIndexOf('@') + 1)).Value
    for ($k = 0; $k -lt $DENYRXI.Count; $k++) { $hostPart = $DENYRXI[$k].Replace($hostPart, "[deny word #$($k + 1)]") }
    foreach ($pr in $PATRX) { $value = $hostPart; if ($pr[0] -ceq 'hex-id') { $value = $hostPart.ToLowerInvariant() }; if ($pr[1].IsMatch($value)) { $hostPart = Mask $hostPart; break } }
    if ($hostPart.Length -gt 60) { $hostPart = $hostPart.Substring(0, 60) }
    return @(($scheme + '://' + $hostPart), $login)
}
function Test-MustNotShip([string]$name) {
    $low = $name.ToLowerInvariant()
    return ($low.StartsWith('deny-list', [StringComparison]::Ordinal) -or $low.Contains('.private.') -or $low.EndsWith('.private', [StringComparison]::Ordinal) -or $low.Contains('.bak-'))
}
function Scan-File([string]$p) {
    if ([string]::Equals((Get-RealPath $p), $DENY_REAL, [StringComparison]::OrdinalIgnoreCase)) { return }   # this script's own deny list (by real path only)
    $name = Split-Path -Leaf $p
    if (Test-MustNotShip $name) {
        Write-Output "${p}:0:MUST-NOT-SHIP (a deny list, private file or backup; take it out before you share)"; $script:hits++
        if ($name.ToLowerInvariant().StartsWith('deny-list', [StringComparison]::Ordinal)) { return }   # its lines are private words: never print or rescan them
    }
    $legal = [regex]::IsMatch($name, '^(?i)(license|licence|readme)')
    try { $lines = Read-TextLines $p } catch { Write-Output "${p}:0:could-not-read ($($_.Exception.GetType().Name))"; $script:hits++; return }
    if ($null -eq $lines) { Write-Output "${p}:0:not-text (not scanned as text; counted as a hit; save a text copy as UTF-8 and rescan, or exclude this file from sharing)"; $script:hits++; return }
    $n = 0
    foreach ($line in $lines) {
        $n++
        $low = $line.ToLowerInvariant()
        for ($i = 0; $i -lt $DENYRX.Count; $i++) {
            if ($DENYRX[$i].IsMatch($low)) {
                if ($legal -and -not $STRICT -and $COPY_LINE.IsMatch($line)) {
                    Write-Output "${p}:${n}:allowed-copyright-line (deny word #$($i + 1); not counted; --strict counts it)"; $script:allowed++
                } else {
                    Write-Output "${p}:${n}:deny (word #$($i + 1) in your deny list)"; $script:hits++
                }
            }
        }
        foreach ($x in $EXTRARX) { if ($x[0].IsMatch($low)) { Write-Output "${p}:${n}:personal ($($x[1]); not printed)"; $script:hits++ } }
        foreach ($m in $PERSONAL.Matches($line)) { Write-Output "${p}:${n}:review-personal:$(Mask $m.Value) (family, school or health words: read this line yourself)" }
        $sensitive = New-Object System.Collections.Generic.List[object]
        foreach ($pr in $PATRX) {
            $subject = $line; if ($pr[0] -ceq 'hex-id') { $subject = $low }
            foreach ($m in $pr[1].Matches($subject)) { $sensitive.Add(@($m.Index, ($m.Index + $m.Length))); Write-Output "${p}:${n}:$($pr[0]):$(Mask $m.Value)"; $script:hits++ }
        }
        foreach ($m in $URL.Matches($line)) {
            $r = Safe-Url $m.Value
            if ($r[1]) { Write-Output "${p}:${n}:url-login (a user name or password in a link; not printed)"; $script:hits++ }
            Write-Output "${p}:${n}:review-url:$($r[0]) (host only)"
        }
        foreach ($m in $CAPSRX.Matches($line)) {
            $w = $m.Value; $wl = $w.ToLowerInvariant(); $base = $wl; if ($wl.EndsWith("'s", [StringComparison]::Ordinal)) { $base = $wl.Substring(0, $wl.Length - 2) }
            if (-not $ALLOW_CAPS.Contains($w) -and -not $DENYSET.Contains($wl) -and -not $DENYTOK.Contains($base) -and -not $DENYTOK.Contains($wl) -and -not $EXTRASET.Contains($wl)) {
                $risky = [regex]::IsMatch($w, '\d')
                foreach ($pr in $PATRX) { $value = $w; if ($pr[0] -ceq 'hex-id') { $value = $wl }; if ($pr[1].IsMatch($value)) { $risky = $true } }
                foreach ($span in $sensitive) { if ($m.Index -lt $span[1] -and ($m.Index + $m.Length) -gt $span[0]) { $risky = $true } }
                $display = $w; if ($risky) { $display = Mask $w }
                if ($caps.ContainsKey($display)) { $caps[$display]++ } else { $caps[$display] = 1 }   # never echo a matched credential
            }
        }
    }
}
function Walk-Dir([string]$dir) {
    # like os.walk with sorted names: this folder's files first, then each subfolder in order; linked folders are not entered
    $files = @(); $dirs = @()
    foreach ($e in [IO.Directory]::GetFileSystemEntries($dir)) {
        $leaf = [IO.Path]::GetFileName($e)
        if ([IO.Directory]::Exists($e)) { $dirs += $leaf } else { $files += $leaf }
    }
    $fs =[string[]]$files; [Array]::Sort($fs, [StringComparer]::Ordinal)
    $ds = [string[]]$dirs; [Array]::Sort($ds, [StringComparer]::Ordinal)
    foreach ($f in $fs) { Scan-File ($dir.TrimEnd('/','\') + [IO.Path]::DirectorySeparatorChar + $f) }
    foreach ($d in $ds) {
        $full = $dir.TrimEnd('/','\') + [IO.Path]::DirectorySeparatorChar + $d
        # like os.walk(followlinks=False) on Python 3.11: skip symbolic links, but DO enter junctions (3.11 walks them)
        $lt = $null; try { $lt = (Get-Item -LiteralPath $full -Force).LinkType } catch { }
        if ($lt -eq 'SymbolicLink') { continue }
        Walk-Dir $full
    }
}
foreach ($a in $targets) {
    if ([IO.Directory]::Exists($a)) { Walk-Dir $a }
    elseif ([IO.File]::Exists($a)) { Scan-File $a }
    else { Write-Output "${a}:0:not-found"; $script:hits++ }
}
# get_Keys(), not .Keys: a scanned word "Keys" would win the dictionary lookup
$keys = [string[]]@($caps.get_Keys()); [Array]::Sort($keys, [StringComparer]::Ordinal)
Write-Output ('CAPITALIZED WORDS FOR HUMAN READ: ' + (($keys | ForEach-Object { "$_($($caps[$_]))" }) -join ', '))
Write-Output "ALLOWED COPYRIGHT LINES: $($script:allowed)"
Write-Output "HITS: $($script:hits)"
Write-Output 'This scan can miss personal details. Read every file yourself before you share it.'
if ($script:hits) { Finish 1 } else { Finish 0 }
