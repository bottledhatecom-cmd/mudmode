# mudmode module: adapters

**Adds:** guidance for connecting an AI with the generic instructions included in this free kit.

**Files:** `AGENTS.md`, `setup/templates/connector-agents.md`, `setup/templates/connector-claude.md` and `FOR-CHAT-APPS/mudmode-chat-setup.md`.
**More:** ready-made per-AI adapters belong to the separate Full Kit and are not included here.
