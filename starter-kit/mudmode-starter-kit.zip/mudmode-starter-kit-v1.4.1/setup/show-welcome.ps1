# mudmode welcome box renderer; content source: setup/WELCOME.md.
# Prints the part of setup/WELCOME.md between the welcome:start and welcome:end marks as a framed
# box, 76 columns wide. WELCOME.md is the same file the AI uses for its welcome reply, so both match.
# Plain ASCII frame by default (safe in Windows PowerShell 5.1 consoles on any code page). Rounded
# box lines only in Windows Terminal or a UTF-8 mac/linux terminal. No color when NO_COLOR is set,
# when output is redirected, or with -NoColor. Reads two kit files; writes nothing.
# Usage: powershell -ExecutionPolicy Bypass -File setup\show-welcome.ps1 [-Folder TEXT]
#        [-Style auto|ascii|unicode] [-Platform auto|windows|unix] [-NoColor]
param(
  [string]$Kit = "",
  [string]$Folder = "",
  [string]$Style = "auto",
  [string]$Platform = "auto",
  [switch]$NoColor
)
$ErrorActionPreference = "Stop"
if (-not $Kit) { $Kit = Split-Path -Parent $PSScriptRoot }
$MudBoxWidth = 76
$MudTextWidth = $MudBoxWidth - 4

function Test-MudWelcomeRedirected {
  try { return [Console]::IsOutputRedirected } catch { return $true }
}
function Test-MudWelcomeWindows {
  if ($Platform -eq "windows") { return $true }
  if ($Platform -eq "unix") { return $false }
  return ($env:OS -eq "Windows_NT")
}
function ConvertTo-MudWelcomePlain([string]$t) {
  return $t.Replace('`', '').Replace('**', '').Trim()   # WELCOME.md uses no links (a test checks), so show-welcome.sh matches
}
function Split-MudWelcomeWrap([string]$t, [int]$w) {
  $out = New-Object System.Collections.ArrayList
  $line = ""
  foreach ($word in ($t -split ' ')) {
    if ($word -eq "") { continue }
    while ($word.Length -gt $w) {
      if ($line) { [void]$out.Add($line); $line = "" }
      [void]$out.Add($word.Substring(0, $w)); $word = $word.Substring($w)
    }
    if (-not $line) { $line = $word }
    elseif (($line.Length + 1 + $word.Length) -le $w) { $line = $line + " " + $word }
    else { [void]$out.Add($line); $line = $word }
  }
  if ($line -or $out.Count -eq 0) { [void]$out.Add($line) }
  return ,$out
}

# --- read and fill WELCOME.md -----------------------------------------------------------
$src = [IO.File]::ReadAllText((Join-Path $Kit "setup/WELCOME.md"), [Text.Encoding]::UTF8)
$open = "<!-- welcome:start -->"; $close = "<!-- welcome:end -->"
$a = $src.IndexOf($open); $b = $src.IndexOf($close)
if ($a -lt 0 -or $b -le $a) { throw "WELCOME.md has no welcome:start / welcome:end marks" }
$body = $src.Substring($a + $open.Length, $b - $a - $open.Length)
$ver = "?"; $vf = Join-Path $Kit "VERSION"
if (Test-Path -LiteralPath $vf) { $ver = ([IO.File]::ReadAllText($vf)).Trim() }
if (-not $Folder) { if (Test-MudWelcomeWindows) { $Folder = "%USERPROFILE%\mudmode" } else { $Folder = "~/mudmode" } }
$body = $body.Replace("{{VERSION}}", $ver).Replace("{{FOLDER}}", $Folder)
$col = 1; if (Test-MudWelcomeWindows) { $col = 0 }

# --- build rows: each row is a list of @(text, role) -------------------------------------
# Layout: blank lines in WELCOME.md are ignored. A section is: blank, rule, header (with its "why:"
# line on the same row, right side), then one row per item. A "roles" table is a name grid.
$rows = New-Object System.Collections.ArrayList
function Add-MudWelcomeRow { param($Segs) [void]$rows.Add(@{ k = "row"; s = $Segs }) }
function Add-MudWelcomeBlank { if ($rows.Count -and $rows[$rows.Count - 1].k -eq "blank") { return }; [void]$rows.Add(@{ k = "blank" }) }
function Add-MudWelcomeRule { [void]$rows.Add(@{ k = "rule" }) }
function Add-MudWelcomeText([string]$t, [int]$indent, [string]$role) {
  foreach ($l in (Split-MudWelcomeWrap $t ($MudTextWidth - $indent))) { Add-MudWelcomeRow @(, @(((" " * $indent) + $l), $role)) }
}
$script:Table = New-Object System.Collections.ArrayList
$script:HeaderRow = -1
function Close-MudWelcomeTable {
  if ($script:Table.Count -lt 2) { $script:Table.Clear(); return }
  $grid = ((ConvertTo-MudWelcomePlain $script:Table[0][0]) -eq "roles")
  $items = New-Object System.Collections.ArrayList
  for ($i = 1; $i -lt $script:Table.Count; $i++) {
    $cells = $script:Table[$i]
    if ($cells[0] -match '^:?-+:?$') { continue }
    if ($grid) { [void]$items.Add(@($cells | ForEach-Object { ConvertTo-MudWelcomePlain $_ } | Where-Object { $_ })); continue }
    if ($cells.Count -ge 3) { [void]$items.Add(@((ConvertTo-MudWelcomePlain $cells[$col]), (ConvertTo-MudWelcomePlain $cells[2]))) }
    else { [void]$items.Add(@((ConvertTo-MudWelcomePlain $cells[0]), (ConvertTo-MudWelcomePlain $cells[1]))) }
  }
  $script:Table.Clear()
  if ($grid) {
    foreach ($it in $items) {
      $t = "   "; for ($j = 0; $j -lt $it.Count; $j++) { if ($j -lt $it.Count - 1) { $t += $it[$j].PadRight(14) } else { $t += $it[$j] } }
      Add-MudWelcomeRow @(, @($t, "cmd"))
    }
    return
  }
  $cw = 0; foreach ($it in $items) { if ($it[0].Length -gt $cw) { $cw = $it[0].Length } }
  if ($cw -gt 36) { $cw = 28 }
  $ind = 2; $dx = $ind + $cw + 1; $dw = $MudTextWidth - $dx
  foreach ($it in $items) {
    $d = Split-MudWelcomeWrap $it[1] $dw
    if ($it[0].Length -le $cw) {
      Add-MudWelcomeRow @(@(((" " * $ind) + $it[0].PadRight($cw) + " "), "cmd"), @($d[0], "text"))
      for ($j = 1; $j -lt $d.Count; $j++) { Add-MudWelcomeRow @(, @(((" " * $dx) + $d[$j]), "text")) }
    } else {
      Add-MudWelcomeRow @(, @(((" " * $ind) + $it[0]), "cmd"))
      foreach ($l in $d) { Add-MudWelcomeRow @(, @(((" " * $dx) + $l), "text")) }
    }
  }
}
$title = ""; $head = ""; $started = $false; $script:SectionCount = 0
function Add-MudWelcomeHeader {
  if ($script:started) { return }; $script:started = $true
  $gap = $MudTextWidth - 1 - $title.Length - $head.Length - 2
  if ($gap -ge 2) { Add-MudWelcomeRow @(@((" " + $title), "title"), @((" " * $gap), "text"), @($head, "head")) }
  else { Add-MudWelcomeRow @(, @((" " + $title), "title")); if ($head) { Add-MudWelcomeRow @(, @((" " + $head), "head")) } }
}
foreach ($raw in ($body -split "`r?`n")) {
  $ln = $raw.Trim()
  if ($ln.StartsWith("|")) { $cells = @($ln.Trim('|').Split('|') | ForEach-Object { $_.Trim() }); [void]$script:Table.Add($cells); continue }
  Close-MudWelcomeTable
  if ($ln.StartsWith("<!--")) { continue }
  if ($ln.StartsWith("# ")) { $title = ConvertTo-MudWelcomePlain $ln.Substring(2); continue }
  if ($ln.StartsWith("> ")) { $head = ConvertTo-MudWelcomePlain $ln.Substring(2); continue }
  if ($ln -eq "") { continue }
  Add-MudWelcomeHeader
  if ($ln.StartsWith("## ")) {
    if ($script:SectionCount++) { Add-MudWelcomeBlank }; Add-MudWelcomeRule
    Add-MudWelcomeRow @(, @((" " + (ConvertTo-MudWelcomePlain $ln.Substring(3)).ToUpperInvariant()), "section"))
    $script:HeaderRow = $rows.Count - 1; continue
  }
  if ($ln.StartsWith("- ")) {
    $wrapped = Split-MudWelcomeWrap (ConvertTo-MudWelcomePlain $ln.Substring(2)) ($MudTextWidth - 5)
    Add-MudWelcomeRow @(@("   ", "text"), @("*", "dot"), @((" " + $wrapped[0]), "text"))
    for ($j = 1; $j -lt $wrapped.Count; $j++) { Add-MudWelcomeRow @(, @(("     " + $wrapped[$j]), "text")) }
    continue
  }
  $para = ConvertTo-MudWelcomePlain $ln
  if ($para -match '^(?i)on windows') {
    if (-not (Test-MudWelcomeWindows)) { continue }
    if ($para -match '^(?i)on windows:\s+(.+)$') { Add-MudWelcomeRow @(, @(("   " + $Matches[1]), "cmd")); continue }
  }
  if ($para.StartsWith("why: ") -and $script:HeaderRow -ge 0 -and $script:HeaderRow -eq ($rows.Count - 1)) {
    $why = $para.Substring(5); $hs = $rows[$script:HeaderRow].s; $hl = $hs[0][0].Length
    $gap = $MudTextWidth - $hl - $why.Length - 2
    if ($gap -ge 2) { $rows[$script:HeaderRow].s = @($hs[0], @((" " * $gap), "text"), @($why, "why")); continue }
  }
  if ($para -match '^[0-9]+\. ') { Add-MudWelcomeText $para 3 "text"; continue }
  Add-MudWelcomeText $para 1 "text"
}
Close-MudWelcomeTable
Add-MudWelcomeHeader
Add-MudWelcomeBlank

# --- style ---------------------------------------------------------------------------------
$redir = Test-MudWelcomeRedirected
$st = $Style
if ($env:MUDMODE_WELCOME_STYLE) { $st = $env:MUDMODE_WELCOME_STYLE }
if ($st -ne "ascii" -and $st -ne "unicode") {
  $st = "ascii"
  if (-not $redir) {
    if (Test-MudWelcomeWindows) { if ($env:WT_SESSION) { $st = "unicode" } }
    elseif ((("" + $env:LC_ALL + $env:LC_CTYPE + $env:LANG) -match '(?i)utf-?8')) { $st = "unicode" }
  }
}
$useColor = (-not $NoColor) -and (-not $redir) -and (-not $env:NO_COLOR) -and ($env:TERM -ne "dumb")
if ($st -eq "unicode") {
  $h = [string][char]0x2500; $v = [string][char]0x2502
  $tl = [string][char]0x256D; $tr = [string][char]0x256E; $bl = [string][char]0x2570; $br = [string][char]0x256F
  $ml = [string][char]0x251C; $mr = [string][char]0x2524; $dot = [string][char]0x2022
} else {
  $h = "-"; $v = "|"; $tl = "+"; $tr = "+"; $bl = "+"; $br = "+"; $ml = "+"; $mr = "+"; $dot = "*"
}
$colors = @{ border = "DarkCyan"; title = "Cyan"; head = "Yellow"; section = "Green"; why = "DarkGray"; cmd = "White"; dot = "DarkCyan"; text = "Gray" }
function Write-MudWelcomePart([string]$t, [string]$role, [switch]$End) {
  if ($useColor -and $colors.ContainsKey($role)) { Write-Host $t -NoNewline:(-not $End) -ForegroundColor $colors[$role] }
  else { Write-Host $t -NoNewline:(-not $End) }
}
$line = $h * ($MudBoxWidth - 2)
Write-Host ""
Write-MudWelcomePart ($tl + $line + $tr) "border" -End
foreach ($r in $rows) {
  if ($r.k -eq "rule") { Write-MudWelcomePart ($ml + $line + $mr) "border" -End; continue }
  Write-MudWelcomePart ($v + " ") "border"
  $used = 0
  if ($r.k -eq "row") {
    foreach ($sg in $r.s) {
      $t = $sg[0]; if ($sg[1] -eq "dot") { $t = $dot }
      Write-MudWelcomePart $t $sg[1]; $used += $sg[0].Length
    }
  }
  if ($used -lt $MudTextWidth) { Write-Host (" " * ($MudTextWidth - $used)) -NoNewline }
  Write-MudWelcomePart (" " + $v) "border" -End
}
Write-MudWelcomePart ($bl + $line + $br) "border" -End
