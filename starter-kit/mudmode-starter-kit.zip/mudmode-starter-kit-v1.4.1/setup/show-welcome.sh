#!/bin/sh
# mudmode welcome box renderer; content source: setup/WELCOME.md.
# Prints the part of setup/WELCOME.md between the welcome:start and welcome:end marks as a framed
# box, 76 columns wide, the same layout as show-welcome.ps1. WELCOME.md is the same file the AI
# uses for its welcome reply, so both match. Plain ASCII frame unless this is a UTF-8 terminal.
# No color when NO_COLOR is set, TERM is dumb, output is not a terminal, or with --no-color.
# Reads two kit files; writes nothing. Needs only sh and awk.
# Usage: sh setup/show-welcome.sh [--folder TEXT] [--style auto|ascii|unicode]
#        [--platform unix|windows] [--no-color]
KIT=$(cd "$(dirname "$0")/.." && pwd)
FOLDER=""; STYLE=auto; PLATFORM=unix; COLOR=auto
while [ $# -gt 0 ]; do
  case "$1" in
    --kit) KIT=$2; shift 2 ;;
    --folder) FOLDER=$2; shift 2 ;;
    --style) STYLE=$2; shift 2 ;;
    --platform) PLATFORM=$2; shift 2 ;;
    --no-color) COLOR=no; shift ;;
    *) shift ;;
  esac
done
WELCOME="$KIT/setup/WELCOME.md"
[ -f "$WELCOME" ] || { echo "welcome box skipped: no setup/WELCOME.md" >&2; exit 1; }
VER="?"; [ -f "$KIT/VERSION" ] && VER=$(tr -d ' \r\n' < "$KIT/VERSION")
if [ -z "$FOLDER" ]; then if [ "$PLATFORM" = windows ]; then FOLDER='%USERPROFILE%\mudmode'; else FOLDER='~/mudmode'; fi; fi
[ -n "${MUDMODE_WELCOME_STYLE:-}" ] && STYLE=$MUDMODE_WELCOME_STYLE
if [ "$STYLE" != ascii ] && [ "$STYLE" != unicode ]; then
  STYLE=ascii
  if [ -t 1 ]; then
    case "${LC_ALL:-}${LC_CTYPE:-}${LANG:-}" in *[Uu][Tt][Ff]-8*|*[Uu][Tt][Ff]8*) STYLE=unicode ;; esac
  fi
fi
if [ "$COLOR" = auto ]; then
  COLOR=no
  if [ -t 1 ] && [ -z "${NO_COLOR:-}" ] && [ "${TERM:-}" != dumb ]; then COLOR=yes; fi
fi
if [ "$STYLE" = unicode ]; then
  H=$(printf '\342\224\200'); V=$(printf '\342\224\202'); TL=$(printf '\342\225\255'); TR=$(printf '\342\225\256')
  BL=$(printf '\342\225\260'); BR=$(printf '\342\225\257'); ML=$(printf '\342\224\234'); MR=$(printf '\342\224\244'); DOT=$(printf '\342\200\242')
else
  H=-; V='|'; TL=+; TR=+; BL=+; BR=+; ML=+; MR=+; DOT='*'
fi
ESC=$(printf '\033')
awk -v ver="$VER" -v folder="$FOLDER" -v plat="$PLATFORM" -v color="$COLOR" -v esc="$ESC" \
    -v H="$H" -v V="$V" -v TL="$TL" -v TR="$TR" -v BL="$BL" -v BR="$BR" -v ML="$ML" -v MR="$MR" -v DOT="$DOT" '
function trim(t) { sub(/^[ \t\r]+/, "", t); sub(/[ \t\r]+$/, "", t); return t }
function plain(t) { gsub(/`/, "", t); gsub(/\*\*/, "", t); return trim(t) }
function rep(c, n,   s) { s = ""; while (n-- > 0) s = s c; return s }
function pad(t, n) { while (length(t) < n) t = t " "; return t }
function subst(t, k, v,   i, out) { out = ""; while ((i = index(t, k)) > 0) { out = out substr(t, 1, i - 1) v; t = substr(t, i + length(k)) } return out t }
function wrap(t, w,   n, nw, words, i, word, line) {
  n = 0; line = ""; nw = split(t, words, / +/)
  for (i = 1; i <= nw; i++) {
    word = words[i]; if (word == "") continue
    while (length(word) > w) { if (line != "") { WL[++n] = line; line = "" } WL[++n] = substr(word, 1, w); word = substr(word, w + 1) }
    if (line == "") line = word
    else if (length(line) + 1 + length(word) <= w) line = line " " word
    else { WL[++n] = line; line = word }
  }
  if (line != "" || n == 0) WL[++n] = line
  return n
}
function row1(t, r) { RK[++NR_] = "row"; SN[NR_] = 1; ST[NR_, 1] = t; SR[NR_, 1] = r }
function row2(t1, r1, t2, r2) { RK[++NR_] = "row"; SN[NR_] = 2; ST[NR_, 1] = t1; SR[NR_, 1] = r1; ST[NR_, 2] = t2; SR[NR_, 2] = r2 }
function row3(t1, r1, t2, r2, t3, r3) { row2(t1, r1, t2, r2); SN[NR_] = 3; ST[NR_, 3] = t3; SR[NR_, 3] = r3 }
function blank() { if (NR_ > 0 && RK[NR_] == "blank") return; RK[++NR_] = "blank" }
function rule() { RK[++NR_] = "rule" }
function text(t, ind,   n, i) { n = wrap(t, TW - ind); for (i = 1; i <= n; i++) row1(rep(" ", ind) WL[i], "text") }
function header(   gap) {
  if (started) return; started = 1
  gap = TW - 1 - length(title) - length(head) - 2
  if (gap >= 2) row3(" " title, "title", rep(" ", gap), "text", head, "head")
  else { row1(" " title, "title"); if (head != "") row1(" " head, "head") }
}
function closetable(   i, n, cells, c, cw, ind, dx, dw, k, j, m, cmd, desc, grid, t, g, gn) {
  if (TN < 2) { TN = 0; return }
  split(TROW[1], cells, "|"); grid = (plain(cells[1]) == "roles")
  n = 0
  for (i = 2; i <= TN; i++) {
    c = split(TROW[i], cells, "|")
    for (k = 1; k <= c; k++) cells[k] = trim(cells[k])
    if (cells[1] ~ /^:?-+:?$/) continue
    if (grid) {
      gn = 0; for (k = 1; k <= c; k++) if (plain(cells[k]) != "") g[++gn] = plain(cells[k])
      t = "   "; for (k = 1; k <= gn; k++) t = t (k < gn ? pad(g[k], 14) : g[k])
      row1(t, "cmd"); continue
    }
    n++
    if (c >= 3) { ICMD[n] = plain(plat == "windows" ? cells[1] : cells[2]); IDESC[n] = plain(cells[3]) }
    else { ICMD[n] = plain(cells[1]); IDESC[n] = plain(cells[2]) }
  }
  TN = 0
  cw = 0; for (i = 1; i <= n; i++) if (length(ICMD[i]) > cw) cw = length(ICMD[i])
  if (cw > 36) cw = 28
  ind = 2; dx = ind + cw + 1; dw = TW - dx
  for (i = 1; i <= n; i++) {
    m = wrap(IDESC[i], dw)
    if (length(ICMD[i]) <= cw) {
      row2(rep(" ", ind) pad(ICMD[i], cw) " ", "cmd", WL[1], "text")
      for (j = 2; j <= m; j++) row1(rep(" ", dx) WL[j], "text")
    } else {
      row1(rep(" ", ind) ICMD[i], "cmd")
      for (j = 1; j <= m; j++) row1(rep(" ", dx) WL[j], "text")
    }
  }
}
function paint(t, r) {
  if (color != "yes") return t
  if (r == "border" || r == "dot") return esc "[36m" t esc "[0m"
  if (r == "title") return esc "[1;36m" t esc "[0m"
  if (r == "head") return esc "[33m" t esc "[0m"
  if (r == "section") return esc "[1;32m" t esc "[0m"
  if (r == "cmd") return esc "[1m" t esc "[0m"
  if (r == "why") return esc "[2m" t esc "[0m"
  return t
}
BEGIN { HDR = 0; seen = 0; closed = 0; BW = 76; TW = BW - 4; NR_ = 0; TN = 0; started = 0; inside = 0; title = ""; head = "" }
{
  if (index($0, "<!-- welcome:start -->") == 1) { inside = 1; seen = 1; next }
  if (index($0, "<!-- welcome:end -->") == 1) { inside = 0; closed = seen; next }
  if (!inside) next
  ln = trim(subst(subst($0, "{{VERSION}}", ver), "{{FOLDER}}", folder))
  if (substr(ln, 1, 1) == "|") { t = ln; sub(/^\|/, "", t); sub(/\|$/, "", t); TROW[++TN] = t; next }
  closetable()
  if (substr(ln, 1, 4) == "<!--") next
  if (substr(ln, 1, 2) == "# ") { title = plain(substr(ln, 3)); next }
  if (substr(ln, 1, 2) == "> ") { head = plain(substr(ln, 3)); next }
  if (ln == "") next
  header()
  if (substr(ln, 1, 3) == "## ") { if (NSEC++ > 0) blank(); rule(); row1(" " toupper(plain(substr(ln, 4))), "section"); HDR = NR_; next }
  if (substr(ln, 1, 2) == "- ") {
    n = wrap(plain(substr(ln, 3)), TW - 5)
    row3("   ", "text", "*", "dot", " " WL[1], "text")
    for (j = 2; j <= n; j++) row1("     " WL[j], "text")
    next
  }
  para = plain(ln)
  if (tolower(substr(para, 1, 10)) == "on windows") {
    if (plat != "windows") next
    if (tolower(substr(para, 1, 11)) == "on windows:") { t = substr(para, 12); sub(/^[ \t]+/, "", t); if (t != "") { row1("   " t, "cmd"); next } }
  }
  if (substr(para, 1, 5) == "why: " && HDR > 0 && HDR == NR_ && SN[NR_] == 1) {
    t = substr(para, 6); gap = TW - length(ST[NR_, 1]) - length(t) - 2
    if (gap >= 2) { SN[NR_] = 3; ST[NR_, 2] = rep(" ", gap); SR[NR_, 2] = "text"; ST[NR_, 3] = t; SR[NR_, 3] = "why"; next }
  }
  if (para ~ /^[0-9]+\. /) { text(para, 3); next }
  text(para, 1)
}
END {
  if (!closed) { print "WELCOME.md has no welcome:start / welcome:end marks" > "/dev/stderr"; exit 2 }
  closetable(); header(); blank()
  line = rep(H, BW - 2)
  print ""
  print paint(TL line TR, "border")
  for (i = 1; i <= NR_; i++) {
    if (RK[i] == "rule") { print paint(ML line MR, "border"); continue }
    out = paint(V " ", "border"); used = 0
    if (RK[i] == "row") for (j = 1; j <= SN[i]; j++) { t = ST[i, j]; used += length(t); if (SR[i, j] == "dot") t = DOT; out = out paint(t, SR[i, j]) }
    if (used < TW) out = out rep(" ", TW - used)
    print out paint(" " V, "border")
  }
  print paint(BL line BR, "border")
}' "$WELCOME"
