<!-- welcome:start -->
# mudmode free kit v{{VERSION}}
> one mind, many ai.

one plain rule book your ai is asked to follow, kept in your own files.

## what it's for
why: rules and notes for your ai

- your ai is asked to follow CORE.md, plus your CORE-LOCAL.md
- it is asked to check first before money, sending or deleting
- one OK = one action: your OK covers the one thing you named
- handoff: your ai writes a note so the next chat can pick up
- rules, not locks. keep checking your ai's work.

## start here
why: three steps after setup

1. in your mudmode project or connected ai, say: mudmode status
2. say mudhelp for a short list of words you can say
3. say handoff before you stop

in a chat app, paste that note into your next chat.

<!-- gate G1: the mudmode update row below -->
## say this to your ai
why: no buttons or codes; plain words do it

| command | what it does |
|---|---|
| `mudmode status` | what's open, what needs you, next step |
| `handoff` | a note so the next chat can pick up |
| `mudmode report` | daily report: what it's doing and learned |
| `mudgo on / off / auto` | extra rules for technical work |
| `mudmode modules` | see the extra pieces and which are on |
| `change my mudmode settings` | name, time zone, ask-first, word rules |
| `mudmode update` | checks a signed pack, asks, then updates |
| `mudhelp` | a short list of words you can say |

<!-- gate G1 + G2: the signed updates bullet below -->
## what the free kit gives you
why: free to keep; personal, non-commercial

- one rule book (CORE.md), everyday first; mudgo when work needs it
- the one OK = one action rule for anything risky
- handoffs, and a lessons book for notes you choose to keep
- 11 modules you can turn on by name
- setup paths for file ais and chat apps with projects
- signed updates from mudmodecrew.com: checked, backed up, with undo
- plain markdown files; no mudmode account needed to read them
- optional: browser usage estimates; windows wake for webhook bots

<!-- gate G3: 20 roles row. gate G4: submit row. gate G5: founding 200 row -->
## free kit and full kit
why: start free; the full kit adds more

| | |
|---|---|
| `free kit` | rule book, handoffs, lessons, modules |
| `full kit adds` | the full manual (MUDMODE.md) |
| | ready-made per-ai adapters |
| | a crew of 20 roles you can rename |
| | submit: a local zip you review and send |
| | optional claude code hooks |
| `full kit price` | $29 one time, on gumroad |
| `founding 200` | full kit: $15 for the first 200 buyers |

keep using the free kit. if you want more later:
<!-- gate G5: if founding 200 sells out, this line becomes: full kit: mudmodecrew.com -->
full kit and founding 200: mudmodecrew.com
<!-- welcome:end -->
