# AGENTS.md: mudmode free kit, v1.4.1

This folder is the mudmode free kit. This is the main file for AIs that work with files: Codex, Cursor, Grok Build and others read it on their own, and Claude Code reads it through `CLAUDE.md`.

- If the owner asked you to set them up, follow `setup/AI-SETUP.md` in this folder now. If you can't read or write files on this computer, follow `FOR-CHAT-APPS/mudmode-chat-lite.md` instead.
- The rules are in `CORE.md` (the safety core). It wins if anything else differs.
- Not sure what the owner can say? See `WHAT-TO-SAY.md`.
- Connector templates are in `setup/templates/connector-claude.md` and `setup/templates/connector-agents.md`. This free kit does not bundle Claude Code agents or skills.
